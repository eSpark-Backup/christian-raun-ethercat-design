/*
 * Encoder.h
 *
 *  Created on: 2018��8��8��
 *      Author: Dark
 */

#ifndef ANANAS_DAC_PROJECTWARE_ENCODER_H_
#define ANANAS_DAC_PROJECTWARE_ENCODER_H_

#include "stm32f0xx_hal.h"
#include "main.h"

#define ENCODER_ONE_CYCLE 25600//4096*4

//void TIM3_IRQHandler(void)
//{
//  /* USER CODE BEGIN TIM3_IRQn 0 */
//	(htim3.Instance->CR1 & 0x10) ? QEI_encoderCycle-- : QEI_encoderCycle++;
//  /* USER CODE END TIM3_IRQn 0 */
//  HAL_TIM_IRQHandler(&htim3);
//  /* USER CODE BEGIN TIM3_IRQn 1 */
//
//  /* USER CODE END TIM3_IRQn 1 */
//}

extern long QEI_encoderValue;
extern volatile uint8_t QEI_encoderDir;
extern volatile long QEI_encoderCycle;

extern SPI_HandleTypeDef hspi2;
//extern TIM_HandleTypeDef htim3;


long read_Encoder();
void initla_encoder();
long read_QEI_encoder();

#endif /* ANANAS_DAC_PROJECTWARE_ENCODER_H_ */
