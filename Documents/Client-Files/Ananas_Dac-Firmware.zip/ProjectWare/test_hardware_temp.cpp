/*
 * test_hardware_temp.c
 *
 *  Created on: 2018年4月24日
 *      Author: Dark
 */

#include "test_hardware_temp.h"
#include "main.h"

CanTxMsgTypeDef TxMessage;
CanRxMsgTypeDef can_rx_msg;
CanRxMsgTypeDef can_rx_msg1;

uint8_t reindex = 0;
uint8_t ret;
void test_CAN_send(CAN_HandleTypeDef *hcan) {

	TxMessage.ExtId = 0x1314; //使用的扩展ID 10
	TxMessage.IDE = CAN_ID_EXT; //扩展模式 11
	TxMessage.RTR = CAN_RTR_DATA; //CAN_RTR_DATA; //发送的是数据 12
	TxMessage.DLC = 3; //数据长度为2字节 13
	TxMessage.Data[0] = 0xAB;
	TxMessage.Data[1] = 0xCD;
	TxMessage.Data[2] = reindex;
	hcan->pRxMsg = &can_rx_msg;
	hcan->pRx1Msg = &can_rx_msg1;
	hcan->pTxMsg = &TxMessage;
	ret = HAL_CAN_Transmit(hcan, 300);

	reindex = reindex + 1;

}

void HAL_CAN_ErrorCallback(CAN_HandleTypeDef *hcan) {
	HAL_GPIO_TogglePin(led_GPIO_Port, led_Pin);
}

void CAN_Config(CAN_HandleTypeDef *CanHandle )
{
  CAN_FilterConfTypeDef  sFilterConfig;
  static CanTxMsgTypeDef        TxMessage;
  static CanRxMsgTypeDef        RxMessage;

  /*##-1- Configure the CAN peripheral #######################################*/
  CanHandle->Instance = CAN;
  CanHandle->pTxMsg = &TxMessage;
  CanHandle->pRxMsg = &RxMessage;

  CanHandle->Init.TTCM = DISABLE;
  CanHandle->Init.ABOM = DISABLE;
  CanHandle->Init.AWUM = DISABLE;
  CanHandle->Init.NART = DISABLE;
  CanHandle->Init.RFLM = DISABLE;
  CanHandle->Init.TXFP = DISABLE;
  CanHandle->Init.Mode = CAN_MODE_NORMAL;
  CanHandle->Init.SJW = CAN_SJW_1TQ;
  CanHandle->Init.BS1 = CAN_BS1_13TQ;//CAN_BS1_4TQ;
  CanHandle->Init.BS2 = CAN_BS2_2TQ;//CAN_BS2_3TQ;
  CanHandle->Init.Prescaler = 6;//12;

  if (HAL_CAN_Init(CanHandle) != HAL_OK)
  {
    /* Initialization Error */
//    Error_Handler();
  }

  /*##-2- Configure the CAN Filter ###########################################*/
  sFilterConfig.FilterNumber = 0;
  sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
  sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
  sFilterConfig.FilterIdHigh = 0x0000;
  sFilterConfig.FilterIdLow = 0x0000;
  sFilterConfig.FilterMaskIdHigh = 0x0000;
  sFilterConfig.FilterMaskIdLow = 0x0000;
  sFilterConfig.FilterFIFOAssignment = 0;
  sFilterConfig.FilterActivation = ENABLE;
  sFilterConfig.BankNumber = 14;

  if (HAL_CAN_ConfigFilter(CanHandle, &sFilterConfig) != HAL_OK)
  {
    /* Filter configuration Error */
//    Error_Handler();
  }

  /*##-3- Configure Transmission process #####################################*/
  CanHandle->pTxMsg->StdId = 0x321;
  CanHandle->pTxMsg->ExtId = 0x01;
  CanHandle->pTxMsg->RTR = CAN_RTR_DATA;
  CanHandle->pTxMsg->IDE = CAN_ID_STD;
  CanHandle->pTxMsg->DLC = 2;

  if (HAL_CAN_Receive_IT(CanHandle, CAN_FIFO0) != HAL_OK)
  {
    /* Reception Error */
//    Error_Handler();
  }
}

#if defined(TEST_PIN_STATE)
uint8_t pinstate[3]={0,0,0};
void ReadInput(){
	pinstate[0] = HAL_GPIO_ReadPin(Step_IN_GPIO_Port,Step_IN_Pin);
	pinstate[1] = HAL_GPIO_ReadPin(Dir_IN_GPIO_Port,Dir_IN_Pin);
	pinstate[2] = HAL_GPIO_ReadPin(Enable_IN_GPIO_Port,Enable_IN_Pin);
}
#endif
