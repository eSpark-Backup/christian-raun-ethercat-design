/*================================================================================================
 *
 *�Ŷ�:     <<���ش�ʦ>>
 *
 *��Ŀ����: jx.shen
 *��ʱ��ϵ: 55954781
 *��ϵ����: 55954781shen&gmail.com
 *readme  :
 1)F1 ϵ��оƬ ��������usb �������
 void HAL_PCDEx_SetConnectionState(PCD_HandleTypeDef *hpcd, uint8_t state) {
 if (state == 1) {
 HAL_GPIO_WritePin(usbBoot_GPIO_Port, usbBoot_Pin, GPIO_PIN_SET);
 } else {
 HAL_GPIO_WritePin(usbBoot_GPIO_Port, usbBoot_Pin, GPIO_PIN_RESET);
 }
 }
 2)APP_RX_DATA_SIZE 64
 APP_TX_DATA_SIZE 64
 3) �滻���� ��������жϺ���
 static int8_t CDC_Receive_FS (uint8_t* Buf, uint32_t *Len) {
 extern void cdc_ReceiveIsr(uint8_t *buf,  uint32_t *len);
 cdc_ReceiveIsr(Buf, Len);
 USBD_CDC_SetRxBuffer(hUsbDevice_0, &Buf[0]);
 USBD_CDC_ReceivePacket(hUsbDevice_0);
 return (USBD_OK);
 }
 4�����Ӻ���
 void cdc_ReceiveIsr(uint8_t *buf,  uint32_t *len) {
 usbSerial.rxCallback(buf, len);
 }
 ================================================================================================*/
#include "cpp_usbSerial.h"
//-********************************************************************************************
//   C _ U S B   S E R I A L . C _ U S B   S E R I A L

//-********************************************************************************************
c_usbSerial::c_usbSerial(uint16_t txBufSize, uint16_t rxBufSize) {
	mTxLen = txBufSize;
	mRxLen = rxBufSize;
	errorState = 0;
}
//-********************************************************************************************
void c_usbSerial::printf(const char * format, ...) {
	init();
	if (!isConnect())
		return;
	va_list arg;
	uint16_t cnt = 0;
	va_start(arg, format);
	vsprintf((char *) pPrintBuf, format, arg);
	va_end(arg);
	cnt = strlen((const char*) pPrintBuf);
	//wait for last send finished
//	while (pCDC->TxState) {
//	}
	if (disable == false) {
		if (cnt %64 == 0 && cnt <mTxLen){
			pPrintBuf[cnt] = '\0';
			cnt++;
		}
		CDC_Transmit_FS((uint8_t*) pPrintBuf, cnt);
//		while (CDC_Transmit_FS((uint8_t*) pPrintBuf, cnt) != USBD_OK)
//			;
//		write((uint8_t*) pPrintBuf, cnt);
	}
}

/**
 * print with write and
 * @param format
 */
void c_usbSerial::printfw(const char * format, ...) {
	init();
	if (!isConnect())
		return;
	va_list arg;
	uint16_t cnt = 0;
	va_start(arg, format);
	vsprintf((char *) pPrintBuf, format, arg);
	va_end(arg);
	cnt = strlen((const char*) pPrintBuf);

	if (disable == false) {
//		CDC_Transmit_FS((uint8_t*) pPrintBuf, cnt);
		write((uint8_t*) pPrintBuf, cnt);
	}
}

void c_usbSerial::write(uint8_t *buf, uint16_t len) {
	init();
	if (!isConnect())
		return;

	if (pCDC->TxState) {
		//previous transfer has not finished So Store the Tx data
		for (int i = 0; i < len; i++) {
			if (c_ringBuf::isFull(&mTxRb)) {
				errorState = USB_SERIAL_FLOW_ERROR;
				break;
			} else {
				c_ringBuf::insert(&mTxRb, buf[i]);
			}
		}

	} else {
		//the state is ready
		if (c_ringBuf::isEmpty(&mTxRb) == false) {
			//���Ͷ�����������
			for (int i = 0; i < len; i++) {
				if (c_ringBuf::isFull(&mTxRb)) {
					errorState = USB_SERIAL_FLOW_ERROR;
					break;
				} else {
					c_ringBuf::insert(&mTxRb, buf[i]);
				}
			}
			return;
		}
		if (len > USB_SERIAL_SEND_MAX_LENGTH) {
			int offset = USB_SERIAL_SEND_MAX_LENGTH;
			CDC_Transmit_FS(buf, USB_SERIAL_SEND_MAX_LENGTH);
			for (int i = offset; i < len; i++) {
				if (c_ringBuf::isFull(&mTxRb)) {
					errorState = USB_SERIAL_FLOW_ERROR;
					break;
				} else {
					c_ringBuf::insert(&mTxRb, buf[i]);
				}
			}
		}
	}
}

//-********************************************************************************************
void c_usbSerial::rxCallback(uint8_t *buf, uint32_t *len) {
	init();
	int index = 0;
	while (*len) {
		*len = *len - 1;
		if (++mRxPush >= mRxLen) {
			mRxPush = 0;
		}
#if USE_FREE_RTOS ==1
		osMessagePut(mRxMail, *buf++, 0);
#else
		c_ringBuf::insert(&mRxRb, buf[index]);
		index++;
#endif
	}
}
uint8_t breakData;
void c_usbSerial::test() {
	if ((USB->EP1R & 0x3000) != 0x3000) {
		breakData = 1;
		PCD_SET_EP_RX_STATUS(USB, 1, USB_EP_RX_VALID);
	}
}
//-********************************************************************************************
//   C _ U S B   S E R I A L . R X   I N I T

//-********************************************************************************************
void c_usbSerial::init() {
	if (mInitFlag == true)
		return;
	mInitFlag = true;
	assert_param(mRxRb.buf != 0);
	pPrintBuf = (uint8_t *) malloc(mTxLen);
	assert_param(pPrintBuf != 0);
#if USE_FREE_RTOS ==1
	osMessageQDef(mRxMail, mRxLen, uint8_t);
	mRxMail = osMessageCreate(osMessageQ(mRxMail), NULL);
	osDelay(1000);
#else
	c_ringBuf::init(&mRxRb, mRxLen, (uint8_t *) malloc(mRxLen));
	c_ringBuf::init(&mTxRb, mTxLen, (uint8_t *) malloc(mTxLen));

	extern USBD_HandleTypeDef hUsbDeviceFS;
	pCDC = (USBD_CDC_HandleTypeDef *) hUsbDeviceFS.pClassData;

	HAL_Delay(1000);
#endif
}

void c_usbSerial::update() {
	if (pCDC->TxState == 0) {
		//is ready to send

		int len = c_ringBuf::getLen(&mTxRb);

		if (len > USB_SERIAL_SEND_MAX_LENGTH) {
			len = USB_SERIAL_SEND_MAX_LENGTH;
		}
		for (int i = 0; i < len; i++) {
			pPrintBuf[i] = c_ringBuf::remove(&mTxRb);
		}
		CDC_Transmit_FS(pPrintBuf, len);
	}
}

uint8_t c_usbSerial::error_return() {
	return errorState;
}
//-********************************************************************************************
//   C _ U S B   S E R I A L . I S   C O N N E C T

//-********************************************************************************************
uint8_t c_usbSerial::isConnect() {
//	extern USBD_HandleTypeDef *hUsbDevice_0;
	extern USBD_HandleTypeDef hUsbDeviceFS;

	if (hUsbDeviceFS.dev_state != USBD_STATE_CONFIGURED)
		return 0;

//	if (hUsbDevice_0->dev_state != USBD_STATE_CONFIGURED)
//		return 0;
	return 1;
}

//-********************************************************************************************
//   C _ U S B   S E R I A L . A V A I L A B L E

//-********************************************************************************************
uint16_t c_usbSerial::available() {
	init();
#if USE_FREE_RTOS ==1
	return available(osWaitForever);
#else
	return c_ringBuf::getLen(&mRxRb);
#endif
}

uint16_t c_usbSerial::available(uint32_t delay) {
	init();
#if USE_FREE_RTOS ==1
	uint16_t len;
	osMessagePeek(mRxMail, osWaitForever);
	len = (mRxPush >= mRxPull) ? (mRxPush - mRxPull) : (mRxLen + mRxPush - mRxPull);
	if (len == 0) {
		osEvent v;
		do {
			v=osMessageGet(mRxMail, 0);
		}while (v.status == osEventMessage);
		osMessagePeek(mRxMail, osWaitForever);
		len = (mRxPush >= mRxPull) ? (mRxPush - mRxPull) : (mRxLen + mRxPush - mRxPull);
	}
	return len;
#else
	uint32_t delayT = HAL_GetTick();
	while (c_ringBuf::isEmpty(&mRxRb) == 1) {
		if ((HAL_GetTick() - delayT) >= delay)
			break;
	}
	return c_ringBuf::getLen(&mRxRb);
#endif
}

//-********************************************************************************************
//   C _ U S B   S E R I A L . R E A D

//-********************************************************************************************
uint8_t c_usbSerial::read() {
	init();
#if USE_FREE_RTOS ==1
	osEvent v = osMessageGet(mRxMail, osWaitForever);
	return v.value.v;
#else
	return c_ringBuf::remove(&mRxRb);
#endif
}

//-********************************************************************************************
//   C _ U S B   S E R I A L . R E A D

//-********************************************************************************************
void c_usbSerial::read(uint8_t *pData, uint16_t len) {
	init();
	pData[len] = 0;
	for (uint16_t i = 0; i < len; i++) {
#if USE_FREE_RTOS ==1
		osEvent v = osMessageGet(mRxMail, 0);
		pData[i] = v.value.v;
		if (++mRxPull >= mRxLen) {
			mRxPull = 0;
		}
#else
		pData[i] = c_ringBuf::remove(&mRxRb);
#endif
	}
}

//-********************************************************************************************

