/*================================================================================================
 *
 *�Ŷ�:     <<���ش�ʦ>>
 *
 *��Ŀ����: jx.shen
 *��ʱ��ϵ: 55954781
 *��ϵ����: 55954781shen&gmail.com
 *readme  :
================================================================================================*/
#ifndef __RING_BUF_H__
#define __RING_BUF_H__
#include "stm32f0xx_hal.h"
// ==========================================================================
typedef struct ring_buffer {
    uint8_t *buf;
    uint16_t remoteId;
    uint16_t insertId;
    uint16_t size;
} ring_buffer;

// ==========================================================================
class c_ringBuf {
public:
    static void init(ring_buffer *rb, uint16_t size, uint8_t *buf);
    static uint8_t isFull(ring_buffer *rb);
    static uint8_t isEmpty(ring_buffer *rb);
    static void insert(ring_buffer *rb, uint8_t element);
    static uint8_t remove(ring_buffer *rb);
    static void reset(ring_buffer *rb);
    static uint16_t getNextIndex(ring_buffer *rb, uint16_t index);
    static uint16_t getPreIndex(ring_buffer *rb, uint16_t index);
    static uint16_t getInsertId(ring_buffer *rb) {
        return rb->insertId;
    }
    static uint16_t getRemoteId(ring_buffer *rb) {
        return rb->remoteId;
    }
	static uint16_t getLen(ring_buffer *rb);
};

#endif
// ==========================================================================

