/*================================================================================================
 *
 *�Ŷ�:     <<���ش�ʦ>>
 *
 *��Ŀ����: jx.shen
 *��ʱ��ϵ: 55954781
 *��ϵ����: 55954781shen&gmail.com
 *readme  :
 *
================================================================================================*/

#ifndef __MEMORY_H__
#define __MEMORY_H__
#include "stm32f0xx_hal.h"
#define	MEMORY_BUF_SIZE (1024*4)
//-********************************************************************************************
// �趨�ڴ��С
#define MEMORY_BLOCK_SIZE	16
#define MEMORY_BLOCK_NUM	(MEMORY_BUF_SIZE / MEMORY_BLOCK_SIZE)

//-********************************************************************************************
class c_memory {
public:
    c_memory();
    static void free(void *ptr);
    static void *malloc(uint32_t size);
    static uint8_t   memUsed();
    static void memcpy(void *des,void *src,uint32_t n);
    static void memset(void *s,uint8_t c,uint32_t count);
private:
    static uint32_t memMalloc(uint32_t size);
    static uint8_t memFree(uint32_t offset);
    static uint16_t map[MEMORY_BLOCK_NUM];
    static uint8_t  buf[MEMORY_BUF_SIZE];
    static uint32_t blockNum;
    static uint32_t blockSize;
};
#endif
//-********************************************************************************************

