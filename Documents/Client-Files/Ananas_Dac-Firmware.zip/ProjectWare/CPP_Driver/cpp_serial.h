/*================================================================================================
 *
 *�Ŷ�:     <<���ش�ʦ>>
 *
 *��Ŀ����: jx.shen
 *��ʱ��ϵ: 55954781
 *��ϵ����: 55954781shen&gmail.com
 *readme  : read ����Ϊһ�������Ժ���
 ================================================================================================*/
#ifndef __SERIAL_H__
#define __SERIAL_H__

#include "stm32f0xx_hal.h"
#include "cpp_memory.h"
#include "cpp_ringBuf.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>


typedef enum {
	IO_MODE_POLLING, IO_MODE_INTERRUPU, IO_MODE_DMA
} IO_ModeTypeDef;

#define PRINT_BUF_SEND_IDLE 0
#define PRINT_BUF_A_SEND 1
#define PRINT_BUF_B_SEND 2

typedef enum {
	PRINT_BUF_STATE_IDLE = 0, PRINT_BUF_STATE_SEND, PRINT_BUF_STATE_OPERATED
} print_buf_state_enum;

typedef struct print_buf_struct {
	uint8_t *pPrintbuf;
	uint16_t offset;
	print_buf_state_enum state;
} print_buf_struct;

//-********************************************************************************************
class c_serial: c_memory, c_ringBuf {
public:
	c_serial(UART_HandleTypeDef *USARTx, uint16_t txBufSize, uint16_t rxBufSize,
			IO_ModeTypeDef ioMode);
	void printf(const char* format, ...);
	uint16_t available();						// ���޵ȴ�
	uint16_t available(uint32_t delay);			// ��ʱ�ȴ�
	void read(uint8_t *pData, uint16_t len);
	uint8_t read();
	uint16_t getRxSize();
	void writeCallBack();
	void rxIdleBack();
	void refresh();
	void setIoMode(IO_ModeTypeDef ioMode) {
		mIoMode = ioMode;
	}
	void write(uint8_t data);
	void write(uint8_t *data, uint16_t len);
private:
	void init();
	uint8_t mInitFlag;
	uint8_t *pPrintBuf;
	uint8_t sendbufIndex;
	volatile print_buf_struct PrintBufA;
	volatile print_buf_struct PrintBufB;
	uint16_t mTxLen;
	uint16_t mRxLen;
	ring_buffer mRxRb;
	IO_ModeTypeDef mIoMode;
	UART_HandleTypeDef *pUSARTx;
};

//-********************************************************************************************
#endif

