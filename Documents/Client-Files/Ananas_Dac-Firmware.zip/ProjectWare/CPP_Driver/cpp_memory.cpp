/*================================================================================================
 *
 *�Ŷ�:     <<���ش�ʦ>>
 *
 *��Ŀ����: jx.shen
 *��ʱ��ϵ: 55954781
 *��ϵ����: 55954781shen&gmail.com
 *readme  :
 ================================================================================================*/
#include "cpp_memory.h"

uint8_t c_memory::buf[MEMORY_BUF_SIZE] = { 0 };
uint16_t c_memory::map[MEMORY_BLOCK_NUM] = { 0 };
uint32_t c_memory::blockNum = MEMORY_BLOCK_NUM;
uint32_t c_memory::blockSize = MEMORY_BLOCK_SIZE;

//-********************************************************************************************
//   c_memory. c_memory

//-********************************************************************************************
c_memory::c_memory() {
}
//-********************************************************************************************
//   C _ M E M O R Y . M E M C P Y

//-********************************************************************************************
void c_memory::memcpy(void * des, void * src, uint32_t n) {
	uint8_t *xdes = (uint8_t*) des;
	uint8_t *xsrc = (uint8_t*) src;
	while (n--)
		*xdes++ = *xsrc++;
}
//-********************************************************************************************
//   C _ M E M O R Y . M E M S E T

//-********************************************************************************************
void c_memory::memset(void * s, uint8_t c, uint32_t count) {
	uint8_t *xs = (uint8_t*) s;
	while (count--)
		*xs++ = c;
}
//-********************************************************************************************
//   C _ M E M O R Y . M E M   U S E D

//-********************************************************************************************
uint8_t c_memory::memUsed() {
	uint32_t used = 0;
	for (uint32_t i = 0; i < blockNum; i++) {
		if (map[i])
			used++;
	}
	return (used * 100) / blockNum;
}
//-********************************************************************************************
//   C _ M E M O R Y . M E M   M A L L O C

//-********************************************************************************************
uint32_t c_memory::memMalloc(uint32_t size) {
	uint32_t nmemb, cmemb = 0;
	int32_t offset = blockNum - 1;
	if (size == 0)
		return 0xffffffff;
	(size % blockSize) ?
			(nmemb = size / blockSize + 1) : (nmemb = size / blockSize);
	for (; offset >= 0; offset--) {
		(map[offset]) ? (cmemb = 0) : (cmemb++);
		if (cmemb == nmemb) {
			for (uint32_t i = 0; i < nmemb; i++) {
				map[offset + i] = nmemb;
			}
			return offset * blockSize;
		}
	}
	return 0xffffffff;
}
//-********************************************************************************************
//   C _ M E M O R Y . M E M   F R E E

//-********************************************************************************************
uint8_t c_memory::memFree(uint32_t offset) {
	uint32_t index = offset / blockSize;
	uint32_t nmemb = map[index];

	if (index >= blockNum)
		return 0xff;
	for (uint32_t i = 0; i < nmemb; i++) {
		map[index + i] = 0;
	}
	return 0;
}
//-********************************************************************************************
//   C _ M E M O R Y . F R E E

//-********************************************************************************************
void c_memory::free(void * ptr) {
	if (ptr == 0)
		return;
	uint32_t offset = (uint32_t) ptr - (uint32_t) buf;
	memFree(offset);
}
//-********************************************************************************************
//   C _ M E M O R Y . M A L L O C

//-********************************************************************************************
void * c_memory::malloc(uint32_t size) {
	uint32_t offset = memMalloc(size);
	if (offset == 0xffffffff)
		return 0;
	return (void *) ((uint32_t) buf + offset);
}
//-********************************************************************************************
//
//-********************************************************************************************
