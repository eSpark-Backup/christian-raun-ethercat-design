/*================================================================================================
 *
 *�Ŷ�:     <<���ش�ʦ>>
 *
 *��Ŀ����: jx.shen
 *��ʱ��ϵ: 55954781
 *��ϵ����: 55954781shen&gmail.com
 *readme  :
 1): ���崮���࣬����ͨ�������ͻ����С�����ջ����С������ģʽ
 c_serial lcdSerial(&huart1, 200, 200, IO_MODE_DMA);
 2):���巢�ͻص�����
 void HAL_UART_TxCpltCallback(UART_HandleTypeDef *husart) {
 if (husart == &huart1) {
 lcdSerial.writeCallBack();
 }
 }
 3):������ջص�����
 void HAL_UART_IDLE_Callback(UART_HandleTypeDef *huart) {
 if (huart == &huart1) {
 lcdSerial.rxIdleBack();
 }
 }
 4): �����жϼ���IDLE����
 void USART1_IRQHandler(void) {
 if (huart1.Instance->SR & UART_FLAG_IDLE) {
 extern void HAL_UART_IDLE_Callback(UART_HandleTypeDef *huart);
 HAL_UART_IDLE_Callback(&huart1);
 do {
 __IO uint32_t tmpreg;
 tmpreg = huart1.Instance->SR;
 tmpreg = huart1.Instance->DR;
 UNUSED(tmpreg);
 } while(0);
 huart1.Instance->SR &= ~UART_FLAG_IDLE;
 //Use system function first
 __HAL_UART_CLEAR_IDLEFLAG(&huart1);
 }
 5): ����DMA ʹ��ѭ��ģʽ
 HAL_UART_IRQHandler(&huart1);
 }
 ================================================================================================*/
#include "cpp_serial.h"

//-********************************************************************************************
//   C _ S E R I A L . C _ S E R I A L

//-********************************************************************************************
c_serial::c_serial(UART_HandleTypeDef *USARTx, uint16_t txBufSize,
		uint16_t rxBufSize, IO_ModeTypeDef ioMode) {
	mIoMode = ioMode;
	pUSARTx = USARTx;
	mTxLen = txBufSize / 3; //make buffer to three part
	mRxLen = rxBufSize;
	PrintBufA.offset = 0;
	PrintBufB.offset = 0;
	PrintBufA.state = PRINT_BUF_STATE_IDLE;
	PrintBufB.state = PRINT_BUF_STATE_IDLE;
}

//-********************************************************************************************
//   C _ S E R I A L . T X   I N I T

//-********************************************************************************************
void c_serial::init() {
	if (mInitFlag == true)
		return;
	//	--------------------------------------------------
	// three buffers
	pPrintBuf = (uint8_t *) malloc(mTxLen);
	assert_param(pPrintBuf != 0);
	PrintBufA.pPrintbuf = (uint8_t *) malloc(mTxLen);
	assert_param(PrintBuf1 != 0);
	PrintBufB.pPrintbuf = (uint8_t *) malloc(mTxLen);
	assert_param(PrintBuf2 != 0);

//    c_ringBuf::init(&mTxRb, mTxLen, (uint8_t *)malloc(mTxLen));
//    assert_param(mTxRb.buf != 0);
	c_ringBuf::init(&mRxRb, mRxLen, (uint8_t *) malloc(mRxLen));
	assert_param(mRxRb.buf != 0);

	//	--------------------------------------------------
	//   �����ź�
//    pUSARTx->hdmatx->Init.Mode = DMA_NORMAL;
//    HAL_DMA_Init(pUSARTx->hdmatx);
//    pUSARTx->hdmarx->Init.Mode = DMA_CIRCULAR;
//    HAL_DMA_Init(pUSARTx->hdmarx);
	__HAL_UART_CLEAR_OREFLAG(pUSARTx);    //fix bug
	__HAL_UART_CLEAR_IDLEFLAG(pUSARTx);
	HAL_UART_Receive_DMA(pUSARTx, mRxRb.buf, mRxRb.size + 1);
	__HAL_UART_ENABLE_IT(pUSARTx, UART_IT_IDLE);
	mInitFlag = true;
}

//-********************************************************************************************
//   C _ S E R I A L . P R I N T F

//-********************************************************************************************
void c_serial::printf(const char* format, ...) {
	init();
	va_list arg;
	uint16_t cnt = 0;
	va_start(arg, format);
	vsprintf((char *) pPrintBuf, format, arg);
	cnt = strlen((const char*) pPrintBuf);
	va_end(arg);

	do {
		//Try to add Sting to PrintBufA
		if ((PrintBufA.state == PRINT_BUF_STATE_IDLE)
				&& ((cnt + PrintBufA.offset) <= this->mTxLen)) {
			PrintBufA.state = PRINT_BUF_STATE_OPERATED;
			//There is enough space for this message
			memcpy(&PrintBufA.pPrintbuf[PrintBufA.offset], pPrintBuf, cnt);
			PrintBufA.offset += cnt;
			PrintBufA.state = PRINT_BUF_STATE_IDLE;
			break;
		}

		//Try to add Sting to PrintBufB
		if ((PrintBufB.state == PRINT_BUF_STATE_IDLE)
				&& ((cnt + PrintBufB.offset) <= this->mTxLen)) {
			PrintBufB.state = PRINT_BUF_STATE_OPERATED;
			//There is enough space for this message
			memcpy(&PrintBufB.pPrintbuf[PrintBufB.offset], pPrintBuf, cnt);
			PrintBufB.offset += cnt;
			PrintBufB.state = PRINT_BUF_STATE_IDLE;
			break;
		}
	} while (true);

#ifdef STM32F0
	if (~(pUSARTx->gState != HAL_UART_STATE_BUSY_RX
			&& pUSARTx->gState != HAL_UART_STATE_READY))
#endif
#ifdef STM32F1
	if (~(pUSARTx->State == HAL_UART_STATE_BUSY_TX
					|| pUSARTx->State == HAL_UART_STATE_BUSY_TX_RX))

#endif
#ifdef STM32F4
	if(~(pUSARTx->gState == HAL_UART_STATE_BUSY_TX
					||pUSARTx->gState == HAL_UART_STATE_BUSY_TX_RX))
#endif
	{
		if (sendbufIndex == PRINT_BUF_SEND_IDLE) {
			if (PrintBufA.state == PRINT_BUF_STATE_IDLE
					&& PrintBufA.offset > 0) {
				PrintBufA.state = PRINT_BUF_STATE_SEND;
				sendbufIndex = PRINT_BUF_A_SEND;
				write(PrintBufA.pPrintbuf, PrintBufA.offset);
				return;
			}
			if (PrintBufB.state == PRINT_BUF_STATE_IDLE
					&& PrintBufB.offset > 0) {
				PrintBufB.state = PRINT_BUF_STATE_SEND;
				sendbufIndex = PRINT_BUF_B_SEND;
				write(PrintBufB.pPrintbuf, PrintBufB.offset);
				return;
			}
		}
	}

//#ifdef STM32F0
//	while (pUSARTx->State == HAL_UART_STATE_BUSY_TX
//			|| pUSARTx->State == HAL_UART_STATE_BUSY_TX_RX)
//		;
//#endif

}

//-********************************************************************************************
//   C _ S E R I A L . W R I T E

//-********************************************************************************************
void c_serial::write(uint8_t *pTxData, uint16_t len) {
	init();
	if (mIoMode == IO_MODE_POLLING) {
		HAL_UART_Transmit(pUSARTx, pTxData, len, 200);
	} else if (mIoMode == IO_MODE_INTERRUPU) {
		HAL_UART_Transmit_IT(pUSARTx, pTxData, len);
	} else if (mIoMode == IO_MODE_DMA) {
		while (HAL_OK != HAL_UART_Transmit_DMA(pUSARTx, pTxData, len)) {
#if USE_FREERTOS  == 1
			osDelay(1);
#else
			HAL_Delay(1);
#endif
		}
	}
}

void c_serial::write(uint8_t TxData) {
	init();
	write(&TxData, 1);
}

//-********************************************************************************************
//   C _ S E R I A L . W R I T E   C A L L   B A C K

//-********************************************************************************************
void c_serial::writeCallBack() {
	init();
#ifdef STM32F4
	if (pUSARTx->gState == HAL_UART_STATE_BUSY_TX) {
		pUSARTx->gState = HAL_UART_STATE_READY;
	} else if (pUSARTx->gState == HAL_UART_STATE_BUSY_TX_RX) {
		pUSARTx->gState = HAL_UART_STATE_BUSY_RX;
	}
#endif
#ifdef STM32F1
	if (pUSARTx->State == HAL_UART_STATE_BUSY_TX) {
		pUSARTx->State = HAL_UART_STATE_READY;
	} else if (pUSARTx->State == HAL_UART_STATE_BUSY_TX_RX) {
		pUSARTx->State = HAL_UART_STATE_BUSY_RX;
	}
#endif
#ifdef STM32F0
	if (pUSARTx->gState == HAL_UART_STATE_BUSY_TX) {
		pUSARTx->gState = HAL_UART_STATE_READY;
	} else if (pUSARTx->gState == HAL_UART_STATE_BUSY_TX_RX) {
		pUSARTx->gState = HAL_UART_STATE_BUSY_RX;
	}
#endif
	if (sendbufIndex == PRINT_BUF_A_SEND) {
		PrintBufA.offset = 0;
		PrintBufA.state = PRINT_BUF_STATE_IDLE;
		if (PrintBufB.state == PRINT_BUF_STATE_IDLE && PrintBufB.offset > 0) {
			PrintBufB.state = PRINT_BUF_STATE_SEND;
			sendbufIndex = PRINT_BUF_B_SEND;
			write(PrintBufB.pPrintbuf, PrintBufB.offset);
		} else {
			sendbufIndex = PRINT_BUF_SEND_IDLE;
		}
	} else if (PrintBufB.state == PRINT_BUF_STATE_SEND) {
		PrintBufB.offset = 0;
		PrintBufB.state = PRINT_BUF_STATE_IDLE;
		if (PrintBufA.state == PRINT_BUF_STATE_IDLE && PrintBufA.offset > 0) {
			PrintBufA.state = PRINT_BUF_STATE_SEND;
			sendbufIndex = PRINT_BUF_A_SEND;
			write(PrintBufA.pPrintbuf, PrintBufA.offset);
		} else {
			sendbufIndex = PRINT_BUF_SEND_IDLE;
		}
	}
}

//-********************************************************************************************
//   C _ S E R I A L . R X   C A L L   B A C K

//-********************************************************************************************
void c_serial::rxIdleBack() {
	init();
#ifdef STM32F0
	mRxRb.insertId = mRxRb.size + 1 - pUSARTx->hdmarx->Instance->CNDTR;
#endif
#ifdef STM32F1
	mRxRb.insertId = mRxRb.size + 1 - pUSARTx->hdmarx->Instance->CNDTR;
#endif
#ifdef STM32F4
	mRxRb.tail=mRxRb.size+1-pUSARTx->hdmarx->Instance->NDTR;
#endif
}

//-********************************************************************************************
//   C _ S E R I A L . A V A I L A B L E
//-********************************************************************************************
uint16_t c_serial::available() {
	init();
#if USE_FREERTOS  == 1
	return available(osWaitForever);
#else
//	if (c_ringBuf::isEmpty(&mRxRb) == 1) {
//		return 0;
//	} else {
	return c_ringBuf::getLen(&mRxRb);
//	}
//	return available(0);
#endif
}

uint16_t c_serial::available(uint32_t delay) {
	init();
	uint32_t delayT = HAL_GetTick();
	while (c_ringBuf::isEmpty(&mRxRb)) {
		if ((HAL_GetTick() - delayT) >= delay)
			break;
	}
	return c_ringBuf::getLen(&mRxRb);
}

//-********************************************************************************************
//   C _ S E R I A L . R E A D
//-********************************************************************************************
void c_serial::read(uint8_t * pData, uint16_t len) {
	init();
	pData[len] = 0;
	for (uint16_t i = 0; i < len; i++) {
		pData[i] = c_ringBuf::remove(&mRxRb);
	}
}
uint8_t c_serial::read() {
	init();
	return c_ringBuf::remove(&mRxRb);
}
void c_serial::refresh() {
	init();
	c_ringBuf::reset(&mRxRb);
}
//-********************************************************************************************
//   C _ S E R I A L . G E T   R X   S I Z E
//-********************************************************************************************
uint16_t c_serial::getRxSize() {
	init();
	return mRxLen;
}
//-********************************************************************************************
//
//-********************************************************************************************

