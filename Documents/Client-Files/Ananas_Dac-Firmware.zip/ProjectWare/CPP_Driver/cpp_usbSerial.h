/*================================================================================================
 *
 *�Ŷ�:     <<���ش�ʦ>>
 *
 *��Ŀ����: jx.shen
 *��ʱ��ϵ: 55954781
 *��ϵ����: 55954781shen&gmail.com
 *readme  :
================================================================================================*/
#ifndef __USB_SERIAL_H__
#define __USB_SERIAL_H__
#include "stm32f0xx_hal.h"
#include "cpp_memory.h"
#include "cpp_ringBuf.h"
#include <stdarg.h>
#include <stdio.h>
#include "string.h"
#include "usbd_cdc_if.h"
#define USB_SERIAL_SEND_MAX_LENGTH 63
#define USB_SERIAL_FLOW_ERROR 1

class c_usbSerial: c_ringBuf , c_memory {
public:
    c_usbSerial(uint16_t txBufSize, uint16_t rxBufSize);
    void printf( const char* format, ...);
    void printfw( const char* format, ...);
	void write(uint8_t *buf, uint16_t len);
    uint16_t available();						// ���޵ȴ�
    uint16_t available(uint32_t delay);			// ��ʱ�ȴ�
    void read(uint8_t *pData, uint16_t len);
    uint8_t read();
    void rxCallback(uint8_t *buf,  uint32_t *len);
	uint16_t getRxSize() {return mRxLen;}
	uint8_t isConnect();
	void setDisable(uint8_t i) {disable = i;}
	void test();
    void update(); //handle rx and tx problem
    uint8_t error_return();
private:
    void init();
    USBD_CDC_HandleTypeDef *pCDC;
	uint8_t mInitFlag;
	uint8_t disable;
	uint8_t errorState;
    uint8_t *pPrintBuf;
	//--
#if USE_FREE_RTOS ==1
	osMessageQId mRxMail;
#else
	ring_buffer mRxRb;
	ring_buffer mTxRb;
#endif
    uint16_t mTxLen;
    uint16_t mRxLen;
	uint16_t mRxPush;
	uint16_t mRxPull;
};

//-********************************************************************************************
#endif

