/*================================================================================================
 *
 *�Ŷ�:     <<���ش�ʦ>>
 *
 *��Ŀ����: jx.shen
 *��ʱ��ϵ: 55954781
 *��ϵ����: 55954781shen&gmail.com
 *readme  :
 ================================================================================================*/
#ifndef __CPP_EEP_H__
#define __CPP_EEP_H__

#include "string.h"
#include "stdint.h"
#include "stm32f0xx_hal.h"
#define EEPROM_DEFAULT_VERSION 0.1f
#define EEPROM_PAGE_SIZE		((uint16_t)0x800)

#define EEP_DEFAULT {\
		.mVer = 0.01,\
}

#define MOTO_PARA_DEFAULT {\
		.pushCnt = 0,\
		.pullCnt = 0,\
}

typedef union {
	uint8_t data[EEPROM_PAGE_SIZE];
	float mVer; //�汾
} EEP_union;


//-********************************************************************************************
class c_eep {
public:
	static void init();
	static void reload();
	static void write();		// ����д��
	static void loadDef();			// �����趨
	static uint32_t eeprom_write_time;
private:
	static float eep_version;
	const static EEP_union mRom;
};

//-********************************************************************************************
#endif

