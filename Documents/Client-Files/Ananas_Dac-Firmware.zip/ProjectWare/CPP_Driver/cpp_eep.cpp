/*================================================================================================
 *
 *�Ŷ�:     <<���ش�ʦ>>
 *
 *��Ŀ����: jx.shen
 *��ʱ��ϵ: 55954781
 *��ϵ����: 55954781shen&gmail.com
 *readme  :
 ================================================================================================*/
#include "cpp_eep.h"
#include "Ananas_Motion.h"
const __align(EEPROM_PAGE_SIZE) EEP_union c_eep::mRom = EEP_DEFAULT;
float c_eep::eep_version = EEPROM_DEFAULT_VERSION;
uint32_t c_eep::eeprom_write_time = 0;
/**
 * Reset Flash Offset Time
 */
uint32_t flash_offset = 0;
void reset_flash_offset() {
	flash_offset = 0;
}

/**
 * Compare if there is a different with data and flash rom
 * @param pdata
 * @param prom
 * @param size
 * @return
 */
uint8_t compere_dif_data_2_rom(uint8_t *pdata, uint8_t *prom, uint32_t size) {
	uint8_t data;
	uint8_t rom;
	for (uint32_t i = 0; i < size; i++) {
		data = *(pdata + i);
		rom = *(prom + i + flash_offset);
		if (data != rom) {
			flash_offset += size;
			return true; //there is a different
		}
	}
	flash_offset = flash_offset + size;
	return false; //there is no different
}

/**
 * Read data from flash rom
 * @param pdata
 * @param prom
 * @param size
 */
void read_data_from_rom(uint8_t *pdata, uint8_t *prom, uint32_t size) {
//	for (uint32_t i = 0; i < size; i++) {
//		*pdata = *(prom + i + flash_offset);
//	}
	memcpy(pdata, (prom + flash_offset), size);
	flash_offset += size;
}

/**
 * Write data to flash rom
 * @param pdata
 * @param prom
 * @param size
 */
void write_data_2_rom(uint8_t *pdata, uint8_t *prom, uint32_t size) {
	uint16_t *ram = (uint16_t *) pdata;
	uint32_t addr = (uint32_t) prom;
	for (uint32_t i = 0; i < size; i += 2) {
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, addr + i + flash_offset,
				*ram++);
	}
	flash_offset += size;
}

/**
 * reload eeprom setting form flash rom
 */
void c_eep::init() {
	reset_flash_offset();

	if (compere_dif_data_2_rom((uint8_t *) &eep_version,
			(uint8_t *) c_eep::mRom.data, sizeof(eep_version)) == true) {
		loadDef();
		return;
	}
	reload();
}

void c_eep::reload() {

	reset_flash_offset();
	read_data_from_rom((uint8_t *) &eep_version, (uint8_t *) c_eep::mRom.data,
			sizeof(eep_version));
	read_data_from_rom((uint8_t *) &eeprom_write_time,
			(uint8_t *) c_eep::mRom.data, sizeof(eeprom_write_time));
	read_data_from_rom((uint8_t *) &device_id, (uint8_t *) c_eep::mRom.data,
			sizeof(device_id));
	read_data_from_rom((uint8_t *) &subdevide_choice,
			(uint8_t *) c_eep::mRom.data, sizeof(subdevide_choice));
	read_data_from_rom((uint8_t *) &subdevide,
			(uint8_t *) c_eep::mRom.data, sizeof(subdevide));
	read_data_from_rom((uint8_t *) &pKp,
			(uint8_t *) c_eep::mRom.data, sizeof(pKp));
	read_data_from_rom((uint8_t *) &pKi,
			(uint8_t *) c_eep::mRom.data, sizeof(pKi));
	read_data_from_rom((uint8_t *) &pKd,
			(uint8_t *) c_eep::mRom.data, sizeof(pKd));
	read_data_from_rom((uint8_t *) &iMAX,
			(uint8_t *) c_eep::mRom.data, sizeof(iMAX));
	read_data_from_rom((uint8_t *) &iMMMax,
			(uint8_t *) c_eep::mRom.data, sizeof(iMMMax));
	read_data_from_rom((uint8_t *) &canBaudRate,
			(uint8_t *) c_eep::mRom.data, sizeof(canBaudRate));
	read_data_from_rom((uint8_t *) &dir_direction,
			(uint8_t *) c_eep::mRom.data, sizeof(dir_direction));
	read_data_from_rom((uint8_t *) &enable_direction,
			(uint8_t *) c_eep::mRom.data, sizeof(enable_direction));
	read_data_from_rom((uint8_t *) &enable_mode,
			(uint8_t *) c_eep::mRom.data, sizeof(enable_mode));
	read_data_from_rom((uint8_t *) &care_enable_state,
			(uint8_t *) c_eep::mRom.data, sizeof(care_enable_state));
	read_data_from_rom((uint8_t *) &hardEndstopReversion,
			(uint8_t *) c_eep::mRom.data, sizeof(hardEndstopReversion));
	read_data_from_rom((uint8_t *) &endstop_in_or_out,
			(uint8_t *) c_eep::mRom.data, sizeof(endstop_in_or_out));
}

/**
 *	Write data to falsh ron
 */
void c_eep::write() {
	//check if there is change of data
//	reset_flash_offset();
//	do {
//		if (compere_dif_data_2_rom((uint8_t *) &eep_version,
//				(uint8_t *) c_eep::mRom.data, sizeof(eep_version)) == true) {
//			break;
//		}
//		if (compere_dif_data_2_rom((uint8_t *) &eeprom_write_time,
//				(uint8_t *) c_eep::mRom.data, sizeof(eeprom_write_time))
//				== true) {
//			break;
//		}
//		if (compere_dif_data_2_rom((uint8_t *) &device_id,
//				(uint8_t *) c_eep::mRom.data, sizeof(device_id)) == true) {
//			break;
//		}
//		if (compere_dif_data_2_rom((uint8_t *) &subdevide_choice,
//				(uint8_t *) c_eep::mRom.data, sizeof(subdevide_choice))
//				== true) {
//			break;
//		}
//		if (compere_dif_data_2_rom((uint8_t *) &subdevide,
//				(uint8_t *) c_eep::mRom.data, sizeof(subdevide))
//				== true) {
//			break;
//		}
//		return;
//	} while (0);
	//Start to Write
	reset_flash_offset();
	HAL_FLASH_Unlock();

#ifdef STM32F4
	FLASH_Erase_Sector((uint32_t)&mRom, FLASH_VOLTAGE_RANGE_3);
#endif
#ifdef STM32F1
	FLASH_PageErase((uint32_t)&mRom);
	while (READ_BIT(FLASH->SR, FLASH_SR_BSY));
	CLEAR_BIT(FLASH->CR, FLASH_CR_PER);
#endif
#ifdef STM32F0
	FLASH_PageErase((uint32_t) &mRom);
	while (READ_BIT(FLASH->SR, FLASH_SR_BSY))
		;
	CLEAR_BIT(FLASH->CR, FLASH_CR_PER);
#endif
	eeprom_write_time++;
	write_data_2_rom((uint8_t *) &eep_version, (uint8_t *) &c_eep::mRom.data,
			sizeof(eep_version));
	write_data_2_rom((uint8_t *) &eeprom_write_time,
			(uint8_t *) c_eep::mRom.data, sizeof(eeprom_write_time));
	write_data_2_rom((uint8_t *) &device_id, (uint8_t *) &c_eep::mRom.data,
			sizeof(device_id));
	write_data_2_rom((uint8_t *) &subdevide_choice,
			(uint8_t *) &c_eep::mRom.data, sizeof(subdevide_choice));
	write_data_2_rom((uint8_t *) &subdevide,
			(uint8_t *) &c_eep::mRom.data, sizeof(subdevide));
	write_data_2_rom((uint8_t *) &pKp,
			(uint8_t *) &c_eep::mRom.data, sizeof(pKp));
	write_data_2_rom((uint8_t *) &pKi,
			(uint8_t *) &c_eep::mRom.data, sizeof(pKi));
	write_data_2_rom((uint8_t *) &pKd,
			(uint8_t *) &c_eep::mRom.data, sizeof(pKd));
	write_data_2_rom((uint8_t *) &iMAX,
			(uint8_t *) &c_eep::mRom.data, sizeof(iMAX));
	write_data_2_rom((uint8_t *) &iMMMax,
			(uint8_t *) &c_eep::mRom.data, sizeof(iMMMax));
	write_data_2_rom((uint8_t *) &canBaudRate,
			(uint8_t *) &c_eep::mRom.data, sizeof(canBaudRate));
	write_data_2_rom((uint8_t *) &dir_direction,
			(uint8_t *) &c_eep::mRom.data, sizeof(dir_direction));
	write_data_2_rom((uint8_t *) &enable_direction,
			(uint8_t *) &c_eep::mRom.data, sizeof(enable_direction));
	write_data_2_rom((uint8_t *) &enable_mode,
			(uint8_t *) &c_eep::mRom.data, sizeof(enable_mode));
	write_data_2_rom((uint8_t *) &care_enable_state,
			(uint8_t *) &c_eep::mRom.data, sizeof(care_enable_state));
	write_data_2_rom((uint8_t *) &hardEndstopReversion,
			(uint8_t *) &c_eep::mRom.data, sizeof(hardEndstopReversion));
	write_data_2_rom((uint8_t *) &endstop_in_or_out,
			(uint8_t *) &c_eep::mRom.data, sizeof(endstop_in_or_out));
	HAL_FLASH_Lock();
}

void c_eep::loadDef() {
	motion_parameter_reset();
}
//-********************************************************************************************
