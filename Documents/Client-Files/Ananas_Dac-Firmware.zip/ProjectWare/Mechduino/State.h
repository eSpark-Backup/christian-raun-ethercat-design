//Contains the declaration of the state variables for the control loop  

#ifndef __STATE_H__
#define __STATE_H__

#include "Parameters.h"

//interrupt vars
#ifdef SUBDIVIDE_FLOAT_ANGLE_ENABLE
extern volatile float r;  //setpoint
extern volatile float y;// measured angle
extern volatile float v;// estimated velocity (velocity loop)
extern volatile float yw;
extern volatile float yw_1;
extern volatile float start_up_y;
extern volatile float e;// e = r-y (error)
extern volatile float p;// proportional effort
extern volatile float i;// integral effort

extern volatile float u;//real control effort (not abs)
extern volatile float u_1;
extern volatile float e_1;
extern volatile float u_2;
extern volatile float e_2;
extern volatile float u_3;
extern volatile float e_3;
extern volatile float y_1;

extern volatile float ITerm;
extern volatile float DTerm;
#else

struct AnanasState{
	volatile char care_stop:1;//care stop or not , soft or hardware
	volatile char useSoftEndstop:1;//use soft endstop or not
	volatile char homeDir:1;
	volatile char upStopState:1;
	volatile char downStopState:1;
	volatile char softEndstopTargeted:1;
	volatile char emergency_stop:1;
};

extern AnanasState myAnanasStete;

extern volatile char is_reach_time;
extern volatile char is_reach_target;



extern volatile int travel_time;
extern volatile long r_t;   //target point
extern volatile float r_v;   //target velocity

extern volatile float r;  //setpoint
extern volatile long y;  // measured angle
extern volatile float v;  // estimated velocity (velocity loop)
extern volatile long yw;
extern volatile long yw_1;
extern volatile long start_up_y;
extern volatile long e;  // e = r-y (error)
extern volatile float p;  // proportional effort
extern volatile float i;  // integral effort

extern volatile long u;  //real control effort (not abs)
extern volatile long uk;
extern volatile long u_1;
extern volatile long e_1;
extern volatile long u_2;
extern volatile long e_2;
extern volatile long u_3;
extern volatile long e_3;
extern volatile long y_1;

extern volatile float ITerm;
extern volatile float DTerm;

extern uint32_t abs_e;

#endif
extern volatile int U;  //control effort (abs)
extern volatile long counter;
extern volatile long wrap_count;
extern volatile long step_count;  //For step/dir interrupt
extern volatile long stepNumber; // step index for cal routine

extern volatile char mode;
extern volatile char input_mode;
extern volatile bool dir;
extern volatile bool enable;
extern volatile uint16_t dir_direction;
extern volatile uint16_t enable_direction;
extern volatile uint16_t enable_mode;
extern volatile uint16_t care_enable_state;
extern volatile uint16_t hardEndstopReversion;
extern volatile uint16_t endstop_in_or_out;

extern bool print_yw;     //for step response, under development...

void add_mode_change_time();
void set_input_mode(char mode);
uint8_t is_change_mode_allow();
char get_input_mode();
#endif

