  //Contains the declaration of the state variables for the control loop

#include "stdint.h"
#include "state.h"
//interrupt vars

#ifdef SUBDIVIDE_FLOAT_ANGLE_ENABLE
volatile float r = 0.0;   //setpoint
volatile float y = 0.0;   // measured angle
volatile float v = 0.0;  // estimated velocity  (velocity loop)
volatile float yw = 0.0;  // "wrapped" angle (not limited to 0-360)
volatile float yw_1 = 0.0;
volatile float start_up_y = 0.0;
volatile float e = 0.0;   // e = r-y (error)
volatile float p = 0.0;   // proportional effort
volatile float i = 0.0;   // integral effort


volatile float u = 0.0;     //real control effort (not abs)
volatile float u_1 = 0.0;   //value of u at previous time step, etc...
volatile float e_1 = 0.0;   //these past values can be useful for more complex controllers/filters
volatile float u_2 = 0.0;
volatile float e_2 = 0.0;
volatile float u_3 = 0.0;
volatile float e_3 = 0.0;

volatile float y_1 = 0;

volatile float ITerm;
volatile float DTerm;
#else

AnanasState myAnanasStete;

volatile char is_reach_time = true;
volatile char is_reach_target = true;



volatile int travel_time = 0;
volatile long r_t = 0;   //target point
volatile float r_v = 0;   //target velocity
volatile float r = 0;   //setpoint
volatile long y = 0;   // measured angle
volatile float v = 0.0;  // estimated velocity  (velocity loop)
volatile long yw = 0;  // "wrapped" angle (not limited to 0-360)
volatile long yw_1 = 0;
volatile long start_up_y = 0.0;
volatile long e = 0;   // e = r-y (error)
volatile float p = 0.0;   // proportional effort
volatile float i = 0.0;   // integral effort

volatile long u = 0.0;     //real control effort (not abs)
volatile long uk = 0.0;     //real control effort (not abs)
volatile long u_1 = 0.0;   //value of u at previous time step, etc...
volatile long e_1 = 0.0;   //these past values can be useful for more complex controllers/filters
volatile long u_2 = 0.0;
volatile long e_2 = 0.0;
volatile long u_3 = 0.0;
volatile long e_3 = 0.0;

volatile long y_1 = 0;

volatile float ITerm;
volatile float DTerm;
#endif

volatile int U = 0;       //control effort (abs)
volatile long counter = 0;
volatile long wrap_count = 0;  //keeps track of how many revolutions the motor has gone though (so you can command angles outside of 0-360)
volatile long step_count = 0;  //For step/dir interrupt (closed loop)
volatile long stepNumber = 0; // open loop step number (used by 's' and for cal routine)

volatile char mode = 0;
volatile char input_mode = 0;
volatile bool dir = false;
volatile bool enable = false;

volatile uint16_t dir_direction = 0;
volatile uint16_t enable_direction = 0;
volatile uint16_t enable_mode = 0;
volatile uint16_t care_enable_state = 0;
volatile uint16_t hardEndstopReversion = 0;//false
volatile uint16_t endstop_in_or_out = 1;//false for in true for out


bool print_yw = false;      //for step response, under development...


#define INPUT_MODE_ALLOW_CHANGE_TIME 10 //*0.5s
char mode_change_time_allow = 0;
void add_mode_change_time(){
	mode_change_time_allow ++;

	if(mode_change_time_allow > 100){
		mode_change_time_allow = INPUT_MODE_ALLOW_CHANGE_TIME;
	}
}

void set_input_mode(char mode){
//	if (mode_change_time_allow >= INPUT_MODE_ALLOW_CHANGE_TIME) {
//		mode_change_time_allow = 0;
//		input_mode = mode;
//	}
	input_mode = mode;
}

uint8_t is_change_mode_allow() {
	if (mode_change_time_allow < INPUT_MODE_ALLOW_CHANGE_TIME) {
		return 1;
	}
	return 0;
}

char get_input_mode(){
	return input_mode;
}




