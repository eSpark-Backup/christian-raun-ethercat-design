//Contains TC5 Controller definition
//The main control loop is executed by the TC5 timer interrupt:

//#include <SPI.h>

#include "State.h"
#include "Utils.h"
#include "Parameters.h"
#include "math.h"
#include "encoder.h"
#include "Ananas_Motion.h"

#ifdef SUBDIVIDE_FLOAT_ANGLE_ENABLE
void init_controller() {
	start_up_y = lookup[read_Encoder()];
	y_1 = start_up_y;
	mode = 'x'; //default for x
	enableTCInterrupts();
}

float step_one_time = 0;
void TC5_Handler(TIM_HandleTypeDef * htim) {  // gets called with FPID frequency
	static int print_counter = 0;//this is used by step response

//  if (TC5->COUNT16.INTFLAG.bit.OVF == 1) {    // A counter overflow caused the interrupt

	TEST1_HIGH();//digitalWrite(3, HIGH);       //Fast Write to Digital 3 for debugging

	y = lookup[read_Encoder()];//read encoder and lookup corrected angle in calibration lookup table

	if ((y - y_1) < -180.0)
	wrap_count += 1;//Check if we've rotated more than a full revolution (have we "wrapped" around from 359 degrees to 0 or ffrom 0 to 359?)
	else if ((y - y_1) > 180.0)
	wrap_count -= 1;

	yw = (y + (360.0 * wrap_count));//yw is the wrapped angle (can exceed one revolution)
//	-start_up_y
	if (mode == 'h') {              //choose control algorithm based on mode
		hybridControl();// hybrid control is still under development...
	} else {
		switch (mode) {
			case 'x':         // position control
			e = (r - yw);

			ITerm += (pKi * e);//Integral wind up limit
			if (ITerm > 150.0)
			ITerm = 150.0;
			else if (ITerm < -150.0)
			ITerm = -150.0;

			DTerm = pLPFa * DTerm - pLPFb * pKd * (yw - yw_1);
//			ITerm = 0;
			u = (pKp * e) + ITerm + DTerm;
//			u =
////					(pKp * e)
////					+
//					ITerm
////					+
////					DTerm
//					;

			break;

			case 'v':// velocity controlr
			v = vLPFa * v + vLPFb * (yw - yw_1);//filtered velocity called "DTerm" because it is similar to derivative action in position loop

			e = (r - v);//error in degrees per rpm (sample frequency in Hz * (60 seconds/min) / (360 degrees/rev) )

			ITerm += (vKi * e);//Integral wind up limit
			if (ITerm > 200)
			ITerm = 200;
			else if (ITerm < -200)
			ITerm = -200;

			u = ((vKp * e) + ITerm - (vKd * (e - e_1)));

			//SerialUSB.println(e);
			break;

			case 't':// torque control
			u = 1.0 * r;
			break;
			default:
			u = 0;
			break;
		}

		y_1 = y; //copy current value of y to previous value (y_1) for next control cycle before PA angle added
		if(fabs(e)>PA) {
			step_one_time = PA;
		} else {
			step_one_time = stepangle; //PA;
		}

		if (u > 0.0f) //Depending on direction we want to apply torque, add or subtract a phase angle of PA for max effective torque.  PA should be equal to one full step angle: if the excitation angle is the same as the current position, we would not move!
		{ //You can experiment with "Phase Advance" by increasing PA when operating at high speeds
			y += step_one_time;//update phase excitation angle
			if (u > uMAX)// limit control effort
			u = uMAX;//saturation limits max current command
		} else {
			y -= step_one_time;          //update phase excitation angle
			if (u < -uMAX)// limit control effort
			u = -uMAX;//saturation limits max current command
		}

		U = _abs(u);       //

		if (_abs(e) < 0.1)
		ledPin_HIGH();// turn on LED if error is less than 0.1
		else
		ledPin_LOW();//digitalWrite(ledPin, LOW);

		output(-y, round(U));// update phase currents
	}

	// e_3 = e_2;    //copy current values to previous values for next control cycle
	e_2 = e_1;//these past values can be useful for more complex controllers/filters.  Uncomment as necessary
	e_1 = e;
	// u_3 = u_2;
	u_2 = u_1;
	u_1 = u;
	yw_1 = yw;
	//y_1 = y;

	if (print_yw == true) {    //for step resonse... still under development
		print_counter += 1;
		if (print_counter >= 5) { // print position every 5th loop (every time is too much data for plotter and may slow down control loop
			SerialUSB.printf("%d\n", int(yw * 1024));//*1024 allows us to print ints instead of floats... may be faster
			print_counter = 0;
		}
	}
//    TC5->COUNT16.INTFLAG.bit.OVF = 1;    // writing a one clears the flag ovf flag
	TEST1_LOW();//for testing the control loop timing

//  }

	htim->Instance->CCR1 = htim->Instance->CNT + 1;//PID_TIMER_NUM;
}
#else
extern void Pulse_Process(TIM_HandleTypeDef * htim);

#define MAX_STOP_TIME 5 //max sto time; It handles with motor stop
#define MAX_ERROR_ALLOW 10
#define MAX_OUPUT_TRIGGER_ERROR 128/2 //about a half

float delta_U = 0;
float delta_y = 0;
float add_delta_y = 0;
float error_delta_y = 0;
long encode_read = 0;
uint16_t encode_read_shf = 0;
uint8_t lookup_dif = 0;
int stop_count = 0;
int16_t e_y = 0;
long e_yw = 0;
uint32_t abs_e = 0;
uint32_t low_error_count = 0;
volatile uint16_t max_soft_endstop_care_error = MAX_ERROR_ALLOW;
uint8_t out_put_state = 0;

void init_endstop() {
	if (endstop_in_or_out) {
		GPIO_InitTypeDef GPIO_InitStruct;
		GPIO_InitStruct.Pin = Encoder_A_Pin | Encoder_B_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_PULLUP;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

		HAL_GPIO_WritePin(Encoder_B_GPIO_Port,Encoder_B_Pin,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(Encoder_A_GPIO_Port,Encoder_A_Pin,GPIO_PIN_RESET);
	} else {
		GPIO_InitTypeDef GPIO_InitStruct;
		GPIO_InitStruct.Pin = Encoder_A_Pin | Encoder_B_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_INPUT; //GPIO_MODE_IT_RISING_FALLING;
		GPIO_InitStruct.Pull = GPIO_PULLUP;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	}
}

void read_endstop() {
	if (endstop_in_or_out) {
		myAnanasStete.upStopState = false;
		myAnanasStete.downStopState = false;
	} else {
		myAnanasStete.upStopState = HAL_GPIO_ReadPin(Encoder_A_GPIO_Port,
		Encoder_A_Pin);
		myAnanasStete.downStopState = HAL_GPIO_ReadPin(Encoder_B_GPIO_Port,
		Encoder_B_Pin);
	}
}

void set_out_put(int up_or_down){
	out_put_state = up_or_down;
	if(1 == up_or_down){
		HAL_GPIO_WritePin(Encoder_A_GPIO_Port,Encoder_A_Pin,GPIO_PIN_SET);
	}else if(2 == up_or_down){
		HAL_GPIO_WritePin(Encoder_B_GPIO_Port,Encoder_B_Pin,GPIO_PIN_SET);
	}else{
		HAL_GPIO_WritePin(Encoder_B_GPIO_Port,Encoder_B_Pin,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(Encoder_A_GPIO_Port,Encoder_A_Pin,GPIO_PIN_RESET);
	}
}

void init_start_encoder() {
	encode_read = read_Encoder();
	encode_read_shf = encode_read >> SUBDIVIDE_UINT16_T_SHIFT;
	y = lookup[encode_read_shf]; //read encoder and lookup corrected angle in calibration lookup table
	lookup_dif = encode_read & SUBDIVIDE_UINT16_T_SHIFT_MASK;
	y = y + lookup_dif * default_ratio;
	start_up_y = y;
	wrap_count = 0;
}

void init_controller() {
	output_int(0, uMAX);
	HAL_Delay(100);
	encode_read = read_Encoder();
	encode_read_shf = encode_read >> SUBDIVIDE_UINT16_T_SHIFT;
	y = lookup[encode_read_shf]; //read encoder and lookup corrected angle in calibration lookup table
	lookup_dif = encode_read & SUBDIVIDE_UINT16_T_SHIFT_MASK;
	y = y + lookup_dif * default_ratio;
	start_up_y = y;

	y_1 = start_up_y;
	mode = 'x';            //default for x
	input_mode = 'P'; //锟斤拷锟斤拷
	enableTCInterrupts();
}

void reset_controller() {
	//close the time
	disableTCInterrupts();

	//store the motor state
	add_delta_y = -r * step_2_angle + add_delta_y;
	;

	travel_time = 0;
	r_t = 0;   //target point
	r_v = 0;   //target velocity
	r = 0;   //setpoint
	y = 0;   // measured angle
	v = 0.0;  // estimated velocity  (velocity loop)
	yw = 0;  // "wrapped" angle (not limited to 0-360)
	yw_1 = 0;
	start_up_y = 0.0;
	e = 0;   // e = r-y (error)
	p = 0.0;   // proportional effort
	i = 0.0;   // integral effort

	u = 0.0;     //real control effort (not abs)
	uk = 0.0;     //real control effort (not abs)
	u_1 = 0.0;   //value of u at previous time step, etc...
	e_1 = 0.0; //these past values can be useful for more complex controllers/filters
	u_2 = 0.0;
	e_2 = 0.0;
	u_3 = 0.0;
	e_3 = 0.0;

	y_1 = 0;

	ITerm = 0;
	DTerm = 0;

	delta_U = 0;
	delta_y = 0;

	encode_read = read_Encoder();
	encode_read_shf = encode_read >> SUBDIVIDE_UINT16_T_SHIFT;
	y = lookup[encode_read_shf]; //read encoder and lookup corrected angle in calibration lookup table
	lookup_dif = encode_read & SUBDIVIDE_UINT16_T_SHIFT_MASK;
	y = y + lookup_dif * default_ratio;
	start_up_y = y;
	wrap_count = 0;

	y_1 = start_up_y;
	mode = 'x';            //default for x
	input_mode = 'P'; //锟斤拷锟斤拷
	enableTCInterrupts();
}



/*
 *  闭环电机指令移动、错位矫正功能	
 *
 *	TIM1（当电机动完后使得传感器里的数据改变，此时运行该中断函数一直判断电机是否与目标位置y_1错位，是的话就移动e_y的距离）
 */
void TC5_Handler(TIM_HandleTypeDef * htim) {			//定时器1输出比较事件
	TEST1_HIGH();
	//monitor the time state, It should be same with the time frequent
	PID_time_per_second++;

//	Pulse_Process(htim);
//	return;
	static int print_counter = 0;               //this is used by step response

//digitalWrite(3, HIGH);       //Fast Write to Digital 3 for debugging
	
	
	
	//得到传感器当前实测脉冲数y
	encode_read = read_Encoder();
	encode_read_shf = encode_read >> SUBDIVIDE_UINT16_T_SHIFT;
	y = lookup[encode_read_shf]; //read encoder and lookup corrected angle in calibration lookup table
	lookup_dif = encode_read & SUBDIVIDE_UINT16_T_SHIFT_MASK;
	y = y + lookup_dif * default_ratio;
	
	
	//得到此次电机需要走的脉冲数（错位的脉冲数e_y）
	e_y = (y - y_1);
	if (e_y < -half_steps)			//转半圈脉冲数	
		wrap_count += 1; //Check if we've rotated more than a full revolution (have we "wrapped" around from 359 degrees to 0 or ffrom 0 to 359?)
	else if (e_y > half_steps)
		wrap_count -= 1;

	
	//yw为缠绕角度(可超过一圈)
	yw = (y + (whole_steps * wrap_count)) - start_up_y; //yw is the wrapped angle (can exceed one revolution)
	//copy current value of y to previous value (y_1)
	//for next control cycle before PA angle added
	y_1 = y;

	//emergency stop
	if (myAnanasStete.emergency_stop) {
		goto TIMER_END;
	}
	//control the speed
	if (input_mode == 'C') {				//G0移动命令，输入模式C
		if (false == is_reach_time) {	//输入G0命令后这个变量为false
			if (0 == travel_time) {
				is_reach_time = true;
			}

			if (travel_time) {
				travel_time--;
			}
		}
		
		
		//r_t为目标绝对坐标，r为当前电机绝对坐标，r_v为速度的转化值（一点点r_v挪动电机，直到r到达r_t附近）
		if (false == is_reach_target) {				//判断没有到达目标点
			if (r_t - r >= r_v) {
				r += r_v;
			} else if (r - r_t >= r_v) {
				r -= r_v;
			} else {

				
				//在r_v范围内认为到达了目标点
				r = r_t;
				//has reach the target
				is_reach_target = true;
			}
		}
	}
	
	
	
	//behind the encoder process
	if (myAnanasStete.care_stop) {
		read_endstop();
		if (myAnanasStete.useSoftEndstop) {
			//use soft endstop
			if (myAnanasStete.softEndstopTargeted) {
				//if softEndstopTargeted return
				goto TIMER_END;
			}
		} else {

			if (false == hardEndstopReversion) {
				if (myAnanasStete.homeDir) {
					if (myAnanasStete.downStopState) {
						//return
						//if myAnanasStete.care_stop ==1 so care stop state and stop
						goto TIMER_END;
					}
				} else {
					if (myAnanasStete.upStopState) {
						//if myAnanasStete.care_stop ==1 so care stop state and stop
						goto TIMER_END;

					}
				}
			} else {
				if (myAnanasStete.homeDir) {
					if (myAnanasStete.upStopState) {
						//return
						//if myAnanasStete.care_stop ==1 so care stop state and stop
						goto TIMER_END;
					}
				} else {
					if (myAnanasStete.downStopState) {
						//if myAnanasStete.care_stop ==1 so care stop state and stop
						goto TIMER_END;

					}
				}
			}
		}
	}

	if (mode == 'h') {          //choose control algorithm based on mode
		hybridControl();         // hybrid control is still under development...
	} else {
		switch (mode) {
		case 'x':         // position control
//			if (r - 1000 > yw) {
//				e = 1000;
//			} else if (r + 1000 < yw) {
//				e = -1000;
//			} else {
		
		
			//r这一次函数要挪到的位置绝对坐标值
			e = (r - yw);
//			}
			delta_U = pKp * (e - e_1) + pKi * e + pKd * (e - 2 * e_1 + e_2);
			break;
		case 'v':         // velocity controlr
			u = 0;
			break;
		case 't':         // torque control
			u = 1.0 * r;
			break;
		default:
			u = 0;
			break;
		}

		abs_e = labs(e);
		if (abs_e > max_soft_endstop_care_error) {
			myAnanasStete.softEndstopTargeted = 1;
		} else {
			myAnanasStete.softEndstopTargeted = 0;
		}
		if (e < MAX_ERROR_ALLOW && e > -MAX_ERROR_ALLOW) {
			errorledPin_HIGH(); // turn on LED if error is less than 0.1
			low_error_count++;
		} else {
			errorledPin_LOW(); //digitalWrite(ledPin, LOW);
			low_error_count = 0;
		}

		if(endstop_in_or_out){
			if(abs_e > MAX_OUPUT_TRIGGER_ERROR){
				if(hardEndstopReversion){
					set_out_put(1);
				}else{
					set_out_put(2);
				}
			}else{
				set_out_put(0);
			}
		}else{
			set_out_put(0);
		}

		
		
		//PID计算后的值进行限制
		delta_y -= delta_U;
		if (delta_y > 200) {
			delta_y = 200;
		}
		if (delta_y < -200) {
			delta_y = -200;
		}
		//锟斤拷锟斤拷小锟斤拷锟斤拷,锟斤拷锟劫癸拷锟斤拷
		static float max_delta_y = 0;
		max_delta_y = abs((e >> 2) * step_2_angle);
		if (abs(delta_y) > max_delta_y) {
			delta_y > 0 ? (delta_y = max_delta_y) : (delta_y = -max_delta_y);
		}

		//锟斤拷锟狡讹拷转
		e_yw = yw_1 - yw;
		if (abs(e_yw * step_2_angle) < abs(delta_y)) {
			stop_count++;
		} else {
			stop_count = 0;
		}

		if (stop_count > MAX_STOP_TIME) {
			delta_y > 0 ?
					delta_y = abs(e_yw * step_2_angle) :
					delta_y = -abs(e_yw * step_2_angle); //0;
			stop_count = 0;
		}

		add_delta_y += delta_y;
		stepNumber = -r * step_2_angle + add_delta_y;
		current_control_For_Pulse(abs_e, low_error_count);
		output_int(stepNumber, (uMAX_control));			//uMAX_control = uMAX = 1240
//			output_int(stepNumber, (uMAX));
	}
// e_3 = e_2;    //copy current values to previous values for next control cycle
	e_2 = e_1; //these past values can be useful for more complex controllers/filters.  Uncomment as necessary
	e_1 = e;
// u_3 = u_2;
	u_2 = u_1;
	u_1 = u;
	yw_1 = yw;
//y_1 = y;
	TEST1_LOW();
//for testing the control loop timing
//  }

	TIMER_END: htim->Instance->CCR1 = htim->Instance->CNT + 1; //PID_TIMER_NUM;
}

void Pulse_Process(TIM_HandleTypeDef * htim) {
	encode_read = read_Encoder();
	y = lookup[encode_read]; //read encoder and lookup corrected angle in calibration lookup table

	if ((y - y_1) < -half_steps)
		wrap_count += 1; //Check if we've rotated more than a full revolution (have we "wrapped" around from 359 degrees to 0 or ffrom 0 to 359?)
	else if ((y - y_1) > half_steps)
		wrap_count -= 1;

	yw = (y + (whole_steps * wrap_count)) - start_up_y; //yw is the wrapped angle (can exceed one revolution)
	e = (r - yw);
	abs_e = labs(e);
	stepNumber = -r * step_2_angle + add_delta_y;

//	current_control_For_Pulse(abs_e, low_error_count);
//	output_int(stepNumber, (uMAX_control));
	output_int(stepNumber, (uMAX));				//uMAX = 1240

	htim->Instance->CCR1 = htim->Instance->CNT + 1;
}

#endif

