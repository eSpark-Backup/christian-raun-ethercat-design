//Contains the TC5 Handler declaration


#ifndef __CONTROLLER_H__
#define  __CONTROLLER_H__
#include "Parameters.h"

#define WAIT_TC16_REGS_SYNC(x) while(x->COUNT16.STATUS.bit.SYNCBUSY);

void init_endstop();
void read_endstop();

void init_start_encoder();
void init_controller();
void reset_controller();
void TC5_Handler(TIM_HandleTypeDef * htim);


#endif








