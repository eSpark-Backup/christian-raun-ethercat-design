//Contains the Mechaduino parameter declarations

#ifndef __PARAMETERS_H__
#define __PARAMETERS_H__
#include "Ananas_Dac.h"
#include "cpp_usbSerial.h"
#include "cpp_serial.h"
#include "cpp_gpio.h"
#include "math.h"
#include "stdlib.h"
#include "stdint.h"
#define firmware_version "0.1.3"    //firmware version
#define identifier "x"              // change this to help keep track of multiple mechaduinos (printed on startup)

//#define	SUBDIVIDE_FLOAT_ANGLE_ENABLE
#define	SUBDIVIDE_UINT16_T_ENABLE
#define SUBDIVIDE_UINT16_T_LIST_STEP 4 //2 4
#if SUBDIVIDE_UINT16_T_LIST_STEP ==1
#define SUBDIVIDE_UINT16_T_SHIFT 0
#define SUBDIVIDE_UINT16_T_SHIFT_MASK 0x00000000
#elif SUBDIVIDE_UINT16_T_LIST_STEP ==2
#define SUBDIVIDE_UINT16_T_SHIFT 1
#define SUBDIVIDE_UINT16_T_SHIFT_MASK 0x00000001
#elif SUBDIVIDE_UINT16_T_LIST_STEP == 4
#define	SUBDIVIDE_UINT16_T_SHIFT 2
#define SUBDIVIDE_UINT16_T_SHIFT_MASK 0x00000003
#endif
extern c_usbSerial SerialUSB;
//extern c_serial SerialUSB;
extern c_serial Serial485;
extern c_gpio dir_485;

//----Current Parameters-----

extern volatile float Ts;
extern volatile float Fs;

extern volatile float pKp;
extern volatile float pKi;
extern volatile float pKd;
extern volatile float pLPF;

extern volatile float vKp;
extern volatile float vKi;
extern volatile float vKd;
extern volatile float vLPF;
#ifdef SUBDIVIDE_FLOAT_ANGLE_ENABLE
extern const float lookup[];
#else
extern const uint16_t lookup[];
#endif
extern volatile float pLPFa;
extern volatile float pLPFb;
extern volatile float vLPFa;
extern volatile float vLPFb;

#define FULL_SPR 200
extern int subdivide;
extern const int spr; //  200 steps per revolution
extern long whole_steps;
extern long half_steps;
extern const float aps; // angle per step
extern int cpr; //counts per rev
extern const float stepangle;
extern float step_2_angle;
extern float step_2_devide;
extern volatile float PA;  //

extern float iMAX;
extern const float rSense;
extern volatile int uMAX;
extern float default_ratio;
extern const int16_t sin_1[];
extern volatile uint16_t max_soft_endstop_care_error;
//Defines for pins:

#define IN_4  3
#define IN_3  11
//#define VREF_2 4
//#define VREF_1 9
#define IN_2  2
#define IN_1  0
#define ledPin  13
#define errorledPin 4
#define chipSelectPin 12 //output to chip select

#define step_pin 1
#define dir_pin 0
#define enable_pin 2

//for faster digitalWrite:
#define IN_1_HIGH() GPIOA->ODR |=(0x0001<<IN_1)
#define IN_1_LOW() GPIOA->ODR &=~(0x0001<<IN_1)
#define IN_2_HIGH() GPIOA->ODR |=(0x0001<<IN_2)
#define IN_2_LOW() GPIOA->ODR &=~(0x0001<<IN_2)
#define IN_3_HIGH() GPIOB->ODR |=(0x0001<<IN_3)
#define IN_3_LOW() GPIOB->ODR &=~(0x0001<<IN_3)
#define IN_4_HIGH() GPIOB->ODR |=(0x0001<<IN_4)
#define IN_4_LOW() GPIOB->ODR &=~(0x0001<<IN_4)
#define ledPin_HIGH() GPIOC->ODR |=(0x0001<<ledPin)
#define ledPin_LOW() GPIOC->ODR &=~(0x0001<<ledPin)
#define errorledPin_HIGH() GPIOB->ODR |=(0x0001<<errorledPin)
#define errorledPin_LOW() GPIOB->ODR &=~(0x0001<<errorledPin)
#define CHIPSELECT_HIGH() GPIOB->ODR |=(0x0001<<chipSelectPin)
#define CHIPSELECT_LOW() GPIOB->ODR &=~(0x0001<<chipSelectPin)

#define VREF_1 DAC_CHANNEL_1
#define VREF_2 DAC_CHANNEL_2
#define analogFastWrite(x, y) HAL_DAC_SetValue(&hdac, x, DAC_ALIGN_12B_R, y)

#define micros() HAL_GetTick()

//#define ENABLE_PROFILE_IO    // Define to enable profiling I/O pins

#define PID_TIMER_NUM 2000

#ifdef ENABLE_PROFILE_IO  
#define TEST1   4

#define TEST1_HIGH() GPIOB->ODR |=(0x0001<<TEST1)
#define TEST1_LOW() GPIOB->ODR &=~(0x0001<<TEST1)

#else
//#define TEST1_HIGH() ledPin_HIGH()
//#define TEST1_LOW() ledPin_LOW()
#define TEST1_HIGH()
#define TEST1_LOW()
#endif

#define _sq(x)  ((x)*(x))
#define _max(a, b) ((a>=b) ? (a) : (b))
#define _min(a, b) ((a<=b) ? (a) : (b))
#define _abs(a) ((a > 0) ? (a) : (-(a)))
#define _boundary(in, low, high) ((in<low) ? (low) : ((in>high) ? (high) : (in)))
#define round(a) long(a+0.5)

#define LOOKUP_TABLE_SIZE (long)0x10000

#endif

