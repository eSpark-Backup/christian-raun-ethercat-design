//Contains the definitions of the functions used by the firmware.

//#include <SPI.h>
//#include <Wire.h>

#include "Parameters.h"
#include "Controller.h"
#include "Utils.h"
#include "State.h"
#include "math.h"
#include "stdlib.h"
//#include "analogFastWrite.h"

#include "can_driver.h"
#include "test_hardware_temp.h"
#include "Ananas_Motion.h"
#include "cpp_eep.h"

//if stepper is runing, It do not care about some command
char stepperRuning = false;

void printf_angle();
void dirInterrupt();

char printf_yw;
void setupPins() {

//  pinMode(VREF_2, OUTPUT);
//  pinMode(VREF_1, OUTPUT);
//  pinMode(IN_4, OUTPUT);
//  pinMode(IN_3, OUTPUT);
//  pinMode(IN_2, OUTPUT);
//  pinMode(IN_1, OUTPUT);

//  pinMode(chipSelectPin, OUTPUT); // CSn -- has to toggle high and low to signal chip to start data transfer

//#ifdef ENABLE_PROFILE_IO
//  pinMode(TEST1, OUTPUT);
//#endif
//
//  pinMode(ledPin, OUTPUT); //

// pinMode(clockPin, OUTPUT); // SCL    for I2C
// pinMode(inputPin, INPUT); // SDA
	HAL_DAC_Init(&hdac);
	HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, 0);
	HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, 0);
	HAL_DAC_Start(&hdac, DAC_CHANNEL_1);
	HAL_DAC_Start(&hdac, DAC_CHANNEL_2);

	analogFastWrite(VREF_2, 0.33 * uMAX);
	analogFastWrite(VREF_1, 0.33 * uMAX);

	IN_4_HIGH();   //  digitalWrite(IN_4, HIGH);
	IN_3_LOW();    //  digitalWrite(IN_3, LOW);
	IN_2_HIGH();   //  digitalWrite(IN_2, HIGH);
	IN_1_LOW();    //  digitalWrite(IN_1, LOW);
}

void setupSPI() {

//  SPISettings settingsA(10000000, MSBFIRST, SPI_MODE1);             ///400000, MSBFIRST, SPI_MODE1);
//
//  SPI.begin();    //AS5047D SPI uses mode=1 (CPOL=0, CPHA=1)
//  SerialUSB.printf("Beginning SPI communication with AS5047 encoder...");
//  HAL_Delay(1000);
//  SPI.beginTransaction(settingsA);

}

void configureStepDir() {
//  pinMode(step_pin, INPUT);
//  pinMode(dir_pin, INPUT);
//  attachInterrupt(step_pin, stepInterrupt, RISING);
//  attachInterrupt(dir_pin, dirInterrupt, CHANGE);
}

void configureEnablePin() {
//  pinMode(enable_pin, INPUT);
//  attachInterrupt(enable_pin, enableInterrupt, CHANGE);
}

void stepInterrupt() {
#ifdef SUBDIVIDE_FLOAT_ANGLE_ENABLE
	if (dir)
	r += stepangle;
	else
	r -= stepangle;
#else
	//if enable is false so we do not need to check

	//if the outside pin is enable
	if (enable == false || care_enable_state == false
////			||
//	HAL_GPIO_ReadPin(Enable_IN_GPIO_Port, Enable_IN_Pin) == GPIO_PIN_SET)
			) {
//		enable = true;
		if (dir) {
			r += subdevide;
//		stepNumber += step_2_angle;
		} else {
			r -= subdevide;
//		stepNumber -= step_2_angle;
		}
//	} else {
//		enable = false;
	}

	//��������-�ж���Ӧ������
//	output_int(stepNumber, (uMAX));
#endif
}

void dirInterrupt() {
//  if (REG_PORT_IN0 & PORT_PA11) dir = false; // check if dir_pin is HIGH
//  else dir = true;
	if ((Dir_IN_GPIO_Port->IDR & Dir_IN_Pin) != (uint32_t) GPIO_PIN_RESET) {
		dir = false ^ dir_direction;
	} else {
		dir = true ^ dir_direction;
	}
}

void enableInterrupt() {            //enable pin interrupt handler
//  if (REG_PORT_IN0 & PORT_PA14){   // check if enable_pin is HIGH
	if ((Enable_IN_GPIO_Port->IDR & Enable_IN_Pin)
			!= (uint32_t) GPIO_PIN_RESET) { // check if enable_pin is HIGH
		enable = true ^ enable_direction;
//		enableTCInterrupts();
	} else {
		enable = false ^ enable_direction;
//		disableTCInterrupts();
//		analogFastWrite(VREF_2, 0.33 * uMAX);
//		analogFastWrite(VREF_1, 0.33 * uMAX);
	}

	if (enable_mode == 1) {
		if (enable) {
			disableTCInterrupts();
			r = yw = 0;
			analogFastWrite(VREF_2, 0);
			analogFastWrite(VREF_1, 0);
		} else {
			init_start_encoder();
			enableTCInterrupts();
		}
	}
}

#define MAX_CURRENT 2.5f
#define MIN_CURRENT 0.2f
void setcurrent(float current) {
	if (current > MAX_CURRENT) {
		current = MAX_CURRENT;
	}
	if (current < MIN_CURRENT) {
		current = MIN_CURRENT;
	}

	iMAX = current;
	uMAX = (4095 / 3.3) * (iMAX * 10 * rSense);
}

int angle_1;
int angle_2;
int v_coil_A;
int v_coil_B;

int sin_coil_A;
int sin_coil_B;
int phase_multiplier = 10 * spr / 4;
void output(float theta, int effort) {

	//REG_PORT_OUTCLR0 = PORT_PA09; for debugging/timing

	angle_1 = mod((phase_multiplier * theta), 3600);   //
	angle_2 = mod((phase_multiplier * theta) + 900, 3600);
//	angle_2 = (angle_1+900)%3600;

	sin_coil_A = sin_1[angle_1];

	sin_coil_B = sin_1[angle_2];

	v_coil_A = ((effort * sin_coil_A) / 1024);
	v_coil_B = ((effort * sin_coil_B) / 1024);

	analogFastWrite(VREF_1, _abs(v_coil_A));
	analogFastWrite(VREF_2, _abs(v_coil_B));

	if (v_coil_A >= 0) {
		IN_2_HIGH();  //REG_PORT_OUTSET0 = PORT_PA21;     //write IN_2 HIGH
		IN_1_LOW();   //REG_PORT_OUTCLR0 = PORT_PA06;     //write IN_1 LOW
	} else {
		IN_2_LOW();   //REG_PORT_OUTCLR0 = PORT_PA21;     //write IN_2 LOW
		IN_1_HIGH();  //REG_PORT_OUTSET0 = PORT_PA06;     //write IN_1 HIGH
	}

	if (v_coil_B >= 0) {
		IN_4_HIGH();  //REG_PORT_OUTSET0 = PORT_PA20;     //write IN_4 HIGH
		IN_3_LOW();   //REG_PORT_OUTCLR0 = PORT_PA15;     //write IN_3 LOW
	} else {
		IN_4_LOW();     //REG_PORT_OUTCLR0 = PORT_PA20;     //write IN_4 LOW
		IN_3_HIGH();    //REG_PORT_OUTSET0 = PORT_PA15;     //write IN_3 HIGH
	}

}

void output_int(long steps, int effort) {

//  REG_PORT_OUTCLR0 = PORT_PA09; for debugging/timing

//	angle_1 = mod((step_2_angle * steps), 3600);
//	angle_2 = mod((step_2_angle * steps) + 900, 3600);

	angle_1 = mod((steps), 3600);
	angle_2 = mod((steps) + 900, 3600);

	sin_coil_A = sin_1[angle_1];
	sin_coil_B = sin_1[angle_2];

	v_coil_A = ((effort * sin_coil_A) / 1024);
	v_coil_B = ((effort * sin_coil_B) / 1024);

	analogFastWrite(VREF_1, _abs(v_coil_A));			//DA转换输出（参数：通道，  数字电压）
	analogFastWrite(VREF_2, _abs(v_coil_B));

	if (v_coil_A >= 0) {
		IN_2_HIGH();  //REG_PORT_OUTSET0 = PORT_PA21;     //write IN_2 HIGH
		IN_1_LOW();   //REG_PORT_OUTCLR0 = PORT_PA06;     //write IN_1 LOW
	} else {
		IN_2_LOW();   //REG_PORT_OUTCLR0 = PORT_PA21;     //write IN_2 LOW
		IN_1_HIGH();  //REG_PORT_OUTSET0 = PORT_PA06;     //write IN_1 HIGH
	}

	if (v_coil_B >= 0) {
		IN_4_HIGH();  //REG_PORT_OUTSET0 = PORT_PA20;     //write IN_4 HIGH
		IN_3_LOW();   //REG_PORT_OUTCLR0 = PORT_PA15;     //write IN_3 LOW
	} else {
		IN_4_LOW();     //REG_PORT_OUTCLR0 = PORT_PA20;     //write IN_4 LOW
		IN_3_HIGH();    //REG_PORT_OUTSET0 = PORT_PA15;     //write IN_3 HIGH
	}
}

void calibrate() {   /// this is the calibration routine
	int encoderReading = 0; //or float?  not sure if we can average for more res?
//	int lastencoderReading = 0;
	int avg = 10;               //how many readings to average

	int iStart = 0;     //encoder zero position index
	int jStart = 0;
	int stepNo = 0;

	long fullStepReadings[FULL_SPR];

//	int fullStep = 0;
	int ticks = 0;
	float lookupAngle = 0.0;

	SerialUSB.printf("Beginning calibration routine...\n");

	encoderReading = read_Encoder();
	dir = true;
	oneStep();
	HAL_Delay(500);

	if ((read_Encoder() - encoderReading) < 0) //check which way motor moves when dir = true
			{
		SerialUSB.printf("Wired backwards\n"); // rewiring either phase should fix this.  You may get a false message if you happen to be near the point where the encoder rolls over...
		return;
	}

	while (stepNumber != 0) {       //go to step zero
		if (stepNumber > 0) {
			dir = true;
		} else {
			dir = false;
		}
		oneStep();
		HAL_Delay(100);
	}
	dir = true;
	for (int x = 0; x < spr; x++) { //step through all full step positions, recording their encoder readings

		encoderReading = 0;
		HAL_Delay(100); //moving too fast may not give accurate readings.  Motor needs time to settle after each step.

		for (int reading = 0; reading < avg; reading++) { //average multple readings at each step
			encoderReading += read_Encoder();
			HAL_Delay(10);
		}
		encoderReading = encoderReading / avg;

		fullStepReadings[x] = encoderReading;
		// SerialUSB.printf(fullStepReadings[x], DEC);      //printf readings as a sanity check
		SerialUSB.printf("%.2f\n", 100.0 * x / spr);
//		SerialUSB.printf("%\n");

		oneStep();
	}
//	 SerialUSB.printf(" ");
//	 SerialUSB.printf("ticks:");                        //"ticks" represents the number of encoder counts between successive steps... these should be around 82 for a 1.8 degree stepper
//	 SerialUSB.printf(" ");
	for (int i = 0; i < spr; i++) {
		ticks = fullStepReadings[mod((i + 1), spr)]
				- fullStepReadings[mod((i), spr)];
		if (ticks < -15000) {
			ticks += cpr;

		} else if (ticks > 15000) {
			ticks -= cpr;
		}
//		 SerialUSB.printf("%d ",ticks);

		if (ticks > 1) {                //note starting point with iStart,jStart
			for (int j = 0; j < ticks; j++) {
				stepNo = (mod(fullStepReadings[i] + j, cpr));
//				 SerialUSB.printf("%d ",stepNo);
				if (stepNo == 0) {
					iStart = i;
					jStart = j;
				}

			}
		}

		if (ticks < 1) {                //note starting point with iStart,jStart
			for (int j = -ticks; j > 0; j--) {
				stepNo = (mod(fullStepReadings[spr - 1 - i] + j, cpr));
//				 SerialUSB.printf("%d ",stepNo);
				if (stepNo == 0) {
					iStart = i;
					jStart = j;
				}

			}
		}

	}

	SerialUSB.printf("istart %d  jStart %d", iStart, jStart);
//	SerialUSB.printf("\n"); //The code below generates the lookup table by intepolating between full steps and mapping each encoder count to a calibrated angle
	SerialUSB.printf("\nnewLookup:\n\n"); //The lookup table is too big to store in volatile memory, so we must generate and printf it on the fly
//	SerialUSB.printf("\n"); // in the future, we hope to be able to printf this directly to non-volatile memory

	for (int i = iStart; i < (iStart + spr + 1); i++) {
		ticks = fullStepReadings[mod((i + 1), spr)]
				- fullStepReadings[mod((i), spr)];

		if (ticks < -15000) { //check if current interval wraps over encoder's zero positon
			ticks += cpr;
		} else if (ticks > 15000) {
			ticks -= cpr;
		}
		//Here we printf an interpolated angle corresponding to each encoder count (in order)
		if (ticks > 1) { //if encoder counts were increasing during cal routine...

			if (i == iStart) { //this is an edge case
				for (int j = jStart; j < ticks; j++) {
					lookupAngle =
							0.001
									* mod(
											1000
													* ((aps * i)
															+ ((aps * j)
																	/ float(
																			ticks))),
											360000.0);
					SerialUSB.printf("%0.2f , ", lookupAngle);
				}
			}

			else if (i == (iStart + spr)) { //this is an edge case
				for (int j = 0; j < jStart; j++) {
					lookupAngle =
							0.001
									* mod(
											1000
													* ((aps * i)
															+ ((aps * j)
																	/ float(
																			ticks))),
											360000.0);
					SerialUSB.printf("%.2f , ", lookupAngle);
				}
			} else {                        //this is the general case
				for (int j = 0; j < ticks; j++) {
					lookupAngle =
							0.001
									* mod(
											1000
													* ((aps * i)
															+ ((aps * j)
																	/ float(
																			ticks))),
											360000.0);
					SerialUSB.printf("%.2f , ", lookupAngle);
				}
			}

		}

		else if (ticks < 1) { //similar to above... for case when encoder counts were decreasing during cal routine
			if (i == iStart) {
				for (int j = -ticks; j > (jStart); j--) {
					lookupAngle = 0.001
							* mod(
									1000
											* (aps * (i)
													+ (aps * ((ticks + j))
															/ float(ticks))),
									360000.0);
					SerialUSB.printf("%.2f , ", lookupAngle);
				}
			} else if (i == iStart + spr) {
				for (int j = jStart; j > 0; j--) {
					lookupAngle = 0.001
							* mod(
									1000
											* (aps * (i)
													+ (aps * ((ticks + j))
															/ float(ticks))),
									360000.0);
					SerialUSB.printf("%.2f , ", lookupAngle);
				}
			} else {
				for (int j = -ticks; j > 0; j--) {
					lookupAngle = 0.001
							* mod(
									1000
											* (aps * (i)
													+ (aps * ((ticks + j))
															/ float(ticks))),
									360000.0);
					SerialUSB.printf("%.2f , ", lookupAngle);
				}
			}

		}

	}
	SerialUSB.printf("      \n");

}

uint32_t flash_ffset = 0;
void resetlockup() {
	flash_ffset = 0;
}

void write_data_2_flash(uint8_t *pdata, uint8_t *prom, uint32_t size) {
	uint16_t *ram = (uint16_t *) pdata;
	uint32_t addr = (uint32_t) prom;
	for (uint32_t i = 0; i < size; i += 2) {
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, addr + i + flash_ffset,
				*ram++);
	}
	flash_ffset += size;
}

void printlockup() {
	uint16_t lookupAngle = 0;
	SerialUSB.printf("Look up table");
	long sizeoflookup = 32768; //15 bit
//	uint8_t lookupanglesize = sizeof(lookupAngle);

	for (int i = 0; i < sizeoflookup; i++) {
		lookupAngle = lookup[i];
		SerialUSB.printf("%d , ", lookupAngle);
	}

}

int encoderReading = 0; //or float?  not sure if we can average for more res?
int lastencoderReading = 0;
int avg = 10;               //how many readings to average

int iStart = 0;     //encoder zero position index
int jStart = 0;
int stepNo = 0;

long fullStepReadings[FULL_SPR];

int fullStep = 0;
int ticks = 0;
uint16_t lookupAngle = 0;
long full_step_one_cicle = subdivide * spr;
void calibrate_int() {   /// this is the calibration routine
	disableTCInterrupts();

	SerialUSB.printf("Beginning calibration routine...\n");

	encoderReading = read_Encoder();
	dir = true;
	oneStep();
	HAL_Delay(500);

	if ((read_Encoder() - encoderReading) < 0) //check which way motor moves when dir = true
			{
		SerialUSB.printf("Wired backwards\n"); // rewiring either phase should fix this.  You may get a false message if you happen to be near the point where the encoder rolls over...
		return;
	}

	while (stepNumber != 0) {       //go to step zero
		if (stepNumber > 0) {
			dir = true;
		} else {
			dir = false;
		}
		oneStep();
		HAL_Delay(100);
	}
	dir = true;
	for (int x = 0; x < spr; x++) { //step through all full step positions, recording their encoder readings

		encoderReading = 0;
		HAL_Delay(1000); //moving too fast may not give accurate readings.  Motor needs time to settle after each step.

		for (int reading = 0; reading < avg; reading++) { //average multple readings at each step
			encoderReading += read_Encoder();
			HAL_Delay(20);
		}
		encoderReading = encoderReading / avg;

		fullStepReadings[x] = encoderReading;
		SerialUSB.printf("%d ,", fullStepReadings[x]); //printf readings as a sanity check
		SerialUSB.printf("%.2f ,", 100.0 * x / spr);
		long multi_stepNumber = stepNumber * (step_2_angle) * subdivide;
		SerialUSB.printf("%d ,", multi_stepNumber);
		SerialUSB.printf("%\n");

		oneStep();
	}
//	 SerialUSB.printf(" ");
//	 SerialUSB.printf("ticks:");
//"ticks" represents the number of encoder counts between successive steps... these should be around 82 for a 1.8 degree stepper
//	 SerialUSB.printf(" ");
	for (int i = 0; i < spr; i++) {
		ticks = fullStepReadings[mod((i + 1), spr)]
				- fullStepReadings[mod((i), spr)];
		if (ticks < -15000) {
			ticks += cpr;

		} else if (ticks > 15000) {
			ticks -= cpr;
		}
//		 SerialUSB.printf("%d ",ticks);

		if (ticks > 1) {                //note starting point with iStart,jStart
			for (int j = 0; j < ticks; j++) {
				stepNo = (mod(fullStepReadings[i] + j, cpr));
//				 SerialUSB.printf("%d ",stepNo);
				if (stepNo == 0) {
					iStart = i;
					jStart = j;
				}

			}
		}

		if (ticks < 1) {                //note starting point with iStart,jStart
			for (int j = -ticks; j > 0; j--) {
				stepNo = (mod(fullStepReadings[spr - 1 - i] + j, cpr));
//				 SerialUSB.printf("%d ",stepNo);
				if (stepNo == 0) {
					iStart = i;
					jStart = j;
				}

			}
		}

	}

	SerialUSB.printf("istart %d  jStart %d", iStart, jStart);
//	SerialUSB.printf("\n"); //The code below generates the lookup table by intepolating between full steps and mapping each encoder count to a calibrated angle
	SerialUSB.printf("\nnewLookup:\n\n"); //The lookup table is too big to store in volatile memory, so we must generate and printf it on the fly
//	SerialUSB.printf("\n"); // in the future, we hope to be able to printf this directly to non-volatile memory
	resetlockup();
	long print_num = 0;
	for (int i = iStart; i < (iStart + spr + 1); i++) {
		ticks = fullStepReadings[mod((i + 1), spr)]
				- fullStepReadings[mod((i), spr)];

		if (ticks < -15000) { //check if current interval wraps over encoder's zero positon
			ticks += cpr;
		} else if (ticks > 15000) {
			ticks -= cpr;
		}
		float ratio = float(subdivide) / ticks;
		//Here we printf an interpolated angle corresponding to each encoder count (in order)
		if (ticks > 1) { //if encoder counts were increasing during cal routine...

			if (i == iStart) { //this is an edge case
				for (int j = jStart; j < ticks; j += 1) {
					lookupAngle = mod((i * subdivide) + ((j) * ratio),
							full_step_one_cicle);
					if (print_num % SUBDIVIDE_UINT16_T_LIST_STEP == 0) {
						SerialUSB.printf("%d , ", lookupAngle);

						write_data_2_flash((uint8_t*) &lookupAngle,
								(uint8_t*) &lookup, sizeof(lookupAngle));
					}
				}
			}

			else if (i == (iStart + spr)) { //this is an edge case
				for (int j = 0; j < jStart; j += 1) {
					lookupAngle = mod((i * subdivide) + ((j) * ratio),
							full_step_one_cicle);
					if (print_num % SUBDIVIDE_UINT16_T_LIST_STEP == 0) {
						SerialUSB.printf("%d , ", lookupAngle);
						write_data_2_flash((uint8_t*) &lookupAngle,
								(uint8_t*) &lookup, sizeof(lookupAngle));
					}
				}
			} else {                        //this is the general case
				for (int j = 0; j < ticks; j += 1) {
					lookupAngle = mod((i * subdivide) + ((j) * ratio),
							full_step_one_cicle);
					if (print_num % SUBDIVIDE_UINT16_T_LIST_STEP == 0) {
						SerialUSB.printf("%d , ", lookupAngle);
						write_data_2_flash((uint8_t*) &lookupAngle,
								(uint8_t*) &lookup, sizeof(lookupAngle));
					}
				}
			}

		}

		else if (ticks < 1) { //similar to above... for case when encoder counts were decreasing during cal routine
			if (i == iStart) {
				for (int j = -ticks; j > (jStart); j -= 1) {
					lookupAngle = mod((i * subdivide) + ((j) * ratio),
							full_step_one_cicle);
					if (print_num % SUBDIVIDE_UINT16_T_LIST_STEP == 0) {
						SerialUSB.printf("%d , ", lookupAngle);
						write_data_2_flash((uint8_t*) &lookupAngle,
								(uint8_t*) &lookup, sizeof(lookupAngle));
					}
				}
			} else if (i == iStart + spr) {
				for (int j = jStart; j > 0; j -= 1) {
					lookupAngle = mod((i * subdivide) + ((j) * ratio),
							full_step_one_cicle);
					if (print_num % SUBDIVIDE_UINT16_T_LIST_STEP == 0) {
						SerialUSB.printf("%d , ", lookupAngle);
						write_data_2_flash((uint8_t*) &lookupAngle,
								(uint8_t*) &lookup, sizeof(lookupAngle));
					}
				}
			} else {
				for (int j = -ticks; j > 0; j -= 1) {
					lookupAngle = mod((i * subdivide) + ((j) * ratio),
							full_step_one_cicle);
					if (print_num % SUBDIVIDE_UINT16_T_LIST_STEP == 0) {
						SerialUSB.printf("%d , ", lookupAngle);
						write_data_2_flash((uint8_t*) &lookupAngle,
								(uint8_t*) &lookup, sizeof(lookupAngle));
					}
				}
			}

		}

	}
	SerialUSB.printf("      \n");

}

#define MAX_CHAR_LENGTH 20
float get_a_float_value() {
	int index = 0;
	char value[MAX_CHAR_LENGTH + 1];
	if (SerialUSB.available() == 0) {
		return 0.0f;
	}

	char getchar = SerialUSB.read();
	while (getchar != '\n' && index < MAX_CHAR_LENGTH) {
		value[index] = getchar;
		index++;
		if (SerialUSB.available() > 0) {
			getchar = SerialUSB.read();
		} else {
			break;
		}
	}
	value[index + 1] = '\0';

	return strtod(&value[0], NULL);
}

#define MAX_CMD_SIZE 256
#define MAX_CMD_NUMBER 4

enum CMDSTATE {
	CMD_STATE_EMPTY_CMD = 0,
	CMD_STATE_NO_MORE_BUFFER = 1,
	CMD_STATE_CMD_NOT_COMPLETED = 2,
	CMD_STATE_BUFFER_FULL = 3,
	CMD_STATE_NEW_CMD_GET = 4,
};

static char *strchr_pointer; // just a pointer to find chars in the command string like X, Y, Z, E, etc
static char *cmdbuffer; //for decode
static char *pcmdbuffer; //for get command char
static char cmdbuffers[MAX_CMD_NUMBER][MAX_CMD_SIZE]; //for store command

int store_cmd_number = 0;
int cmd_number = 0;

//use for command
float code_value() {
	return (strtod(strchr_pointer + 1,
	NULL));
}

long code_value_long() {
	return (strtol(strchr_pointer + 1,
	NULL, 10));
}

bool code_seen(char code) {
	strchr_pointer = strchr(cmdbuffer, code);
	return (strchr_pointer != NULL);  //Return True if a character was found
}

bool code_seen(char* buffer, char code) {
	strchr_pointer = strchr(buffer, code);
	return (strchr_pointer != NULL);  //Return True if a character was found
}

int cmd_index = 0;  //cmd_state Index
char checkout = false;  //checkout or not
char get_start = false;
char buffers_head = 0;
char buffers_rear = 0;

#define MOVE_BUFFERS_INDEX(x) (x = (x+1)%MAX_CMD_NUMBER)

void init_cmd_buffers() {
	memset(cmdbuffers, 0, sizeof(cmdbuffers));
	cmdbuffer = cmdbuffers[buffers_rear];
	pcmdbuffer = cmdbuffers[buffers_head];
}

int getcommand() {
	//模拟串口没有接收到数据
	if (SerialUSB.available() == 0) {
		return CMD_STATE_NO_MORE_BUFFER;
	}

	
	//命令条数满了，不接收了
	if ((buffers_head + 1) == buffers_rear
			|| (buffers_head + 1) % MAX_CMD_NUMBER == buffers_rear) {
		//the buffer is full now do not read new data
		return CMD_STATE_BUFFER_FULL;
	}

	char inChar = (char) SerialUSB.read();

	if (inChar == '\n' || inChar == '\r') 			//读取到的是结束符
	{		
		if (cmd_index == 0) {
			SerialUSB.printf("Get A Empty Command\n");
			return CMD_STATE_EMPTY_CMD;
		}
		pcmdbuffer[cmd_index] = 0;
		cmd_index = 0;
		return CMD_STATE_NEW_CMD_GET;
	} 
	else 
	{
		if (cmd_index < MAX_CMD_SIZE) {				//读取到一个字符数据
			pcmdbuffer[cmd_index] = inChar;
		} else {
			pcmdbuffer[MAX_CMD_SIZE - 1] = 0;
			return CMD_STATE_NEW_CMD_GET;
		}
		cmd_index++;
		return CMD_STATE_CMD_NOT_COMPLETED;
	}
}
int ret_getcommmand;
uint16_t checksumCal;
int check_and_store_cmd() {
	//check if checkout is nessensary
	
	
	//接收模拟串口数据
	ret_getcommmand = getcommand();
	if (ret_getcommmand > CMD_STATE_BUFFER_FULL) 			//缓冲区满了
	{
		//get new command
		//check it
		
		
		//查看最新一条命令是否是  "M110"  清空命令数量记录 
		char M110 = (strstr(pcmdbuffer, ("M110")) != NULL);	
		if (M110) {
			store_cmd_number = 0;
			SerialUSB.printf("M110 Reset CMD Number\n");
			return false;
		}

		
		//查看最新一条没有执行的命令是否有  'N'开头命令  记录缓冲区存储的命令的数量
		if (code_seen(cmdbuffers[buffers_head], 'N')) 	
		{
			cmd_number = code_value_long();
			{
				if (cmd_number == store_cmd_number + 1) {
					if (code_seen(cmdbuffers[buffers_head], '*')) 
					{
						int checksum = code_value_long();
						int cmdlength = strlen(cmdbuffers[buffers_head]);
//						uint16_t
						checksumCal = 0;
						for (int i = 0; i < cmdlength; i++) {			//把*之前的全部加起来
							if ('*' != cmdbuffers[buffers_head][i]) {
								checksumCal += cmdbuffers[buffers_head][i];
							} else {
								break;
							}
						}
						checksumCal &= 0x00FF;
						if (checksum == checksumCal) {		//计算的等于得到的数值
							//get a correct
							//head move
							MOVE_BUFFERS_INDEX(buffers_head);	//循环更新最近未执行过的命令的条数(就是+1，到结尾返回起点)
							pcmdbuffer = cmdbuffers[buffers_head];		//将有效命令从缓冲区放到临时数组里
							store_cmd_number = cmd_number;
							SerialUSB.printf("Get CMD OK\n");
							return true;
						}
					}
				}
			}
			//clear the receive buffer
			pcmdbuffer[0] = 0;
//			memset(pcmdbuffer,0,MAX_CMD_SIZE);
		}
		else 
		{
			if (0 == store_cmd_number) 		
			{
				//do not care cmd number
				//head move
				MOVE_BUFFERS_INDEX(buffers_head);
				pcmdbuffer = cmdbuffers[buffers_head];
				SerialUSB.printf("Get CMD OK\n");
				return true;
			}
		}
		
		
		
		if (store_cmd_number != 0) 
		{
			SerialUSB.printf("Resend: last number %d\n", store_cmd_number);
		} 
		else 
		{
			SerialUSB.printf("Resend: last number 1\n");
		}
	} 
	
	
	//缓冲区里有数据
	else if ((buffers_rear) != buffers_head) 
	{
		//there is left data in the buffers
		//process it
		return true;
	}

	return false;
}

void serialCheck() { //Monitors serial for commands.  Must be called in routinely in loop for serial interface to work.

	if (SerialUSB.available()) {

		char inChar = (char) SerialUSB.read();

		switch (inChar) {

		case 'p':             //printf
			printf_angle();
			break;

		case 's':             //step
			oneStep();
			printf_angle();
			break;

		case 'd':             //dir
			if (dir) {
				dir = false;
			} else {
				dir = true;
			}
			break;
#ifdef SUBDIVIDE_FLOAT_ANGLE_ENABLE
			case 'w':                //old command
			calibrate();//cal routine
			break;

			case 'c':
			calibrate();//cal routine
			break;
#else
		case 'w':                //old command
			calibrate_int();           //cal routine
			break;

		case 'c':
			calibrate_int();           //cal routine
			break;
#endif
		case 'e':
			readEncoderDiagnostics();   //encoder error?
			break;

		case 'y':
			enableTCInterrupts();      //enable closed loop
			break;

		case 'n':
			disableTCInterrupts();      //disable closed loop
			break;

		case 'r':             //new setpoint
			SerialUSB.printf("Enter setpoint:");
			while (SerialUSB.available() == 0) {
			}

			r = get_a_float_value();
			SerialUSB.printf("%0.2f\n", r);
			break;

		case 'x':
			mode = 'x';           //position loop
			break;

		case 'v':
			mode = 'v';           //velocity loop
			break;

		case 't':
			mode = 't';           //torque loop
			break;

		case 'h':               //hybrid mode
			mode = 'h';
			break;

		case 'q':
			parameterQuery();     // printfs copy-able parameters
			break;

		case 'a':             //anticogging
			antiCoggingCal();
			break;

		case 'k':
			parameterEditmain();
			break;

		case 'g':
			sineGen();
			break;

		case 'm':
			serialMenu();
			break;

		case 'j':
			stepResponse();
			break;

		default:
			break;
		}
		inChar = 0;
	}
}

void parameterQuery() { //printf current parameters in a format that can be copied directly in to Parameters.cpp
	SerialUSB.printf("\n");
	SerialUSB.printf("----Current Parameters-----");
	SerialUSB.printf("");
	SerialUSB.printf("\n");

	SerialUSB.printf("volatile float Fs = ");
	SerialUSB.printf("%0.2f", Fs);
	SerialUSB.printf(";  //Sample frequency in Hz");
	SerialUSB.printf("\n");

	SerialUSB.printf("volatile float pKp = ");
	SerialUSB.printf("%0.2f", pKp);
	SerialUSB.printf(";      //position mode PID vallues.\n");

	SerialUSB.printf("volatile float pKi = ");
	SerialUSB.printf("%0.2f", pKi);
	SerialUSB.printf(";\n");

	SerialUSB.printf("volatile float pKd = ");
	SerialUSB.printf("%0.2f", pKd);
	SerialUSB.printf(";\n");

	SerialUSB.printf("volatile float pLPF = ");
	SerialUSB.printf("%0.2f", pLPF);
	SerialUSB.printf(";\n");

	SerialUSB.printf("\n");

	SerialUSB.printf("volatile float vKp = ");
	SerialUSB.printf("%0.2f", vKp);
	SerialUSB.printf(";      //velocity mode PID vallues.\n");

	SerialUSB.printf("volatile float vKi = ");
	SerialUSB.printf("%0.2f", vKi);
	SerialUSB.printf(";\n");
// SerialUSB.printf(vKi * Fs, DEC);
// SerialUSB.printf(" / Fs;");

	SerialUSB.printf("volatile float vKd = ");
	SerialUSB.printf("%0.2f", vKd);
	SerialUSB.printf(";\n");
// SerialUSB.printf(vKd / Fs);
// SerialUSB.printf(" * FS;");
	SerialUSB.printf("volatile float vLPF = ");
	SerialUSB.printf("%0.2f", vLPF);
	SerialUSB.printf(";\n");

	SerialUSB.printf("");
	SerialUSB.printf(
			"//This is the encoder lookup table (created by calibration routine)");
	SerialUSB.printf("\n");

	SerialUSB.printf("const float lookup[] = {");
	for (int i = 0; i < 16384; i++) {
		SerialUSB.printf("%0.2f", lookup[i]);
		SerialUSB.printf(", \n");
	}
	SerialUSB.printf("\n");
	SerialUSB.printf("};\n");

}

void oneStep() { /////////////////////////////////   oneStep    ///////////////////////////////

	if (!dir) {
		stepNumber += 1;
	} else {
		stepNumber -= 1;
	}
#ifdef SUBDIVIDE_FLOAT_ANGLE_ENABLE
//output(1.8 * stepNumber, 64); //updata 1.8 to aps..., second number is control effort
//	output(0.0001*(aps * stepNumber), (1 * uMAX));
#else
//	long multi_stepNumber = stepNumber * (subdivide);
	long multi_stepNumber = stepNumber * (step_2_angle) * subdivide;
	output_int(multi_stepNumber, (1 * uMAX));
#endif
	HAL_Delay(1);
}

int readEncoder() //////////////////////////////////////////////////////   READENCODER   ////////////////////////////
{
	long angleTemp = 0;

//  CHIPSELECT_LOW(); //digitalWrite(chipSelectPin, LOW);
//
//  byte b1 = SPI.transfer(0xFF);
//  byte b2 = SPI.transfer(0xFF);
//
//  angleTemp = (((b1 << 8) | b2) & 0B0011111111111111);
//
//  CHIPSELECT_HIGH();   //digitalWrite(chipSelectPin, HIGH);

	return angleTemp;
}

void readEncoderDiagnostics() //////////////////////////////////////////////////////   READENCODERDIAGNOSTICS   ////////////////////////////
{
//	long angleTemp;
	///////////////////////////////////////////////READ DIAAGC (0x3FFC)
	SerialUSB.printf("------------------------------------------------\n");
	SerialUSB.printf("Checking TLE012B diagnostic and error registers\n");
	SerialUSB.printf("See TLE012B datasheet for details\n");
	uint8_t sData[2] = { 0x80, 0x21 };
	uint8_t rData[5] = { 0, 0, 0, 0, 0 };
	CHIPSELECT_LOW();

	HAL_SPI_TransmitReceive(&hspi2, sData, rData, 5, 100);
//	res = (rData[0] << 8 | rData[1]) & 0x7FFF;			//15bit
//	res1 = (rData[0] << 8 | rData[1]) & 0x3FFF;			//14bit
//	res2 = (rData[0] << 9 | rData[1] << 1 | rData[2] >> 7) & 0x7FFF;
//	res3 = (rData[2] << 9 | rData[3] << 1 | rData[4] >> 7) & 0x7FFF;//15bit 32768
//	res3 = (rData[2] << 8 | rData[3]) & 0x3FFF;	//14bit 16384
	CHIPSELECT_HIGH();

	SerialUSB.printf("\n");
	uint8_t tempresult = rData[0] & 0x80;
	if (tempresult > 0) {
		SerialUSB.printf("Indication of chip reset or watchdog overflow!\n");
	}
	tempresult = rData[0] & 0x40;
	if (tempresult > 0) {
		SerialUSB.printf(
				"System error (e.g. overvoltage; undervoltage; VDD-, GND- off; ROM;...)!\n");
	}
	tempresult = rData[0] & 0x20;
	if (tempresult == 0) {
		SerialUSB.printf(
				"Interface access error (access to wrong address; wrong lock)!\n");
	}
	tempresult = rData[0] & 0x10;
	if (tempresult == 0) {
		SerialUSB.printf("Valid angle value (NO_GMR_A = 0; NO_GMR_XY = 0)!\n");
	}
}

void printf_angle() ///////////////////////////////////       printf_ANGLE   /////////////////////////////////
{
	int avg = 10;            //average a few readings
	long encoderReading = 0;
	int rawReading = 0;
	float anglefloat = 0.0;

	disableTCInterrupts();        //can't use readEncoder while in closed loop

	for (int reading = 0; reading < avg; reading++) { //average multple readings at each step
		rawReading = read_Encoder();
		encoderReading += rawReading;
		HAL_Delay(10);
	}

	anglefloat = encoderReading * 0.02197265625 / avg; //    360/16384 = 0.021972....
	SerialUSB.printf("stepNumber: ");
	SerialUSB.printf("%d", stepNumber);
	SerialUSB.printf(" , ");
//  SerialUSB.printf(stepNumber * aps, DEC);
//  SerialUSB.printf(" , ");
	SerialUSB.printf("Angle: ");
	SerialUSB.printf("%0.2f ", anglefloat);
	SerialUSB.printf("AngleLookUp: ");
	SerialUSB.printf("%0.2f ", lookup[read_Encoder()]);
	SerialUSB.printf("Raw Angle");
	SerialUSB.printf("%d\n", rawReading);
}

void receiveEvent(int howMany) {
//  while (1 < Wire.available()) // loop through all but the last
//  {
//    char c = Wire.read(); // receive byte as a character
//    SerialUSB.printf(c);         // printf the character
//  }
//  int x = Wire.read();    // receive byte as an integer
//  SerialUSB.printf(x);         // printf the integer
//  r = 0.1 * ((float)x);
}

inline int mod(int xMod, int mMod) {
	return (xMod % mMod + mMod) % mMod;
}

void setupTCInterrupts() { // configure the controller interrupt

//  // Enable GCLK for TC4 and TC5 (timer counter input clock)
//  GCLK->CLKCTRL.reg = (uint16_t) (GCLK_CLKCTRL_CLKEN | GCLK_CLKCTRL_GEN_GCLK0 | GCLK_CLKCTRL_ID(GCM_TC4_TC5));
//  while (GCLK->STATUS.bit.SYNCBUSY);
//
//  TC5->COUNT16.CTRLA.reg &= ~TC_CTRLA_ENABLE;   // Disable TCx
//  WAIT_TC16_REGS_SYNC(TC5)                      // wait for sync
//
//  TC5->COUNT16.CTRLA.reg |= TC_CTRLA_MODE_COUNT16;   // Set Timer counter Mode to 16 bits
//  WAIT_TC16_REGS_SYNC(TC5)
//
//  TC5->COUNT16.CTRLA.reg |= TC_CTRLA_WAVEGEN_MFRQ; // Set TC as normal Normal Frq
//  WAIT_TC16_REGS_SYNC(TC5)
//
//  TC5->COUNT16.CTRLA.reg |= TC_CTRLA_PRESCALER_DIV1;   // Set perscaler
//  WAIT_TC16_REGS_SYNC(TC5)
//
//  TC5->COUNT16.CC[0].reg = (int)( round(48000000 / Fs)); //0x3E72; //0x4AF0;
//  WAIT_TC16_REGS_SYNC(TC5)
//
//  TC5->COUNT16.INTENSET.reg = 0;              // disable all interrupts
//  TC5->COUNT16.INTENSET.bit.OVF = 1;          // enable overfollow
//  TC5->COUNT16.INTENSET.bit.MC0 = 1;         // enable compare match to CC0
//
//  NVIC_SetPriority(TC5_IRQn, 1);              //Set interrupt priority
//
//  // Enable InterruptVector
//  NVIC_EnableIRQ(TC5_IRQn);
//
//  // Enable TC
//  //  TC5->COUNT16.CTRLA.reg |= TC_CTRLA_ENABLE;
//  //  WAIT_TC16_REGS_SYNC(TC5)

	htim1.Init.Prescaler = round(HAL_RCC_GetHCLKFreq() / Fs);		//分频系数，得到4000HZ频率
	;
	htim1.Init.Period = 0xffff;			//重装载值  计65536次发生一次溢出		需16.384s
	HAL_TIM_Base_Init(&htim1);
}

void enableTCInterrupts() { //enables the controller interrupt ("closed loop mode")
//  TC5->COUNT16.CTRLA.reg |= TC_CTRLA_ENABLE;    //Enable TC5
//  WAIT_TC16_REGS_SYNC(TC5)                      //wait for sync
	htim1.Instance->CCR1 = htim1.Instance->CNT + 2000;
	__HAL_TIM_ENABLE_IT(&htim1, TIM_IT_CC1);
	HAL_TIM_Base_Start(&htim1);
}

void disableTCInterrupts() { //disables the controller interrupt ("closed loop mode")
//  TC5->COUNT16.CTRLA.reg &= ~TC_CTRLA_ENABLE;   // Disable TC5
//  WAIT_TC16_REGS_SYNC(TC5)                      // wait for sync
	__HAL_TIM_DISABLE_IT(&htim1, TIM_IT_CC1);
	HAL_TIM_Base_Stop(&htim1);
}

void antiCoggingCal() { //This is still under development...  The idea is that we can calibrate out the stepper motor's detent torque by measuring the torque required to hold all possible positions.
	SerialUSB.printf(
			" -----------------BEGIN ANTICOGGING CALIBRATION!----------------");
	mode = 'x';
	r = lookup[1];
	enableTCInterrupts();
	HAL_Delay(1000);

	for (int i = 1; i < 657; i++) {
		r = lookup[i];
		SerialUSB.printf("%0.2f", r);
		SerialUSB.printf(" , ");
		HAL_Delay(100);
		SerialUSB.printf("%0.2f", u);
	}
	SerialUSB.printf(" -----------------REVERSE!----------------");

	for (int i = 656; i > 0; i--) {
		r = lookup[i];
		SerialUSB.printf("%0.2f", r);
		SerialUSB.printf(" , ");
		HAL_Delay(100);
		SerialUSB.printf("%0.2f", u);
	}
	SerialUSB.printf(" -----------------DONE!----------------");
	disableTCInterrupts();
}

void parameterEditmain() {

	SerialUSB.printf("\n");
	SerialUSB.printf("Edit parameters:\n");
	SerialUSB.printf("\n");
	SerialUSB.printf("p ----- position loop\n");
	SerialUSB.printf("v ----- velocity loop\n");
	SerialUSB.printf("o ----- other\n");
	SerialUSB.printf("q ----- quit\n");
	SerialUSB.printf("\n");

	while (SerialUSB.available() == 0) {
	}
	char inChar2 = (char) SerialUSB.read();

	switch (inChar2) {
	case 'p': {
		parameterEditp();
	}
		break;

	case 'v': {
		parameterEditv();
	}
		break;

	case 'o': {
		parameterEdito();
	}
		break;
	default: {
	}
		break;

	}
}

void parameterEditp() {

	bool quit = false;
	while (!quit) {
		SerialUSB.printf("Edit position loop gains:");
		SerialUSB.printf("\n");
		SerialUSB.printf("p ----- pKp = ");
		SerialUSB.printf("%0.2f\n", pKp);
		SerialUSB.printf("i ----- pKi = ");
		SerialUSB.printf("%0.2f\n", pKi);
		SerialUSB.printf("d ----- pKd = ");
		SerialUSB.printf("%0.2f\n", pKd);
		SerialUSB.printf("l----- LPF = ");
		SerialUSB.printf("%0.2f\n", pLPF);
		SerialUSB.printf("q ----- quit");
		SerialUSB.printf("\n");

		while (SerialUSB.available() == 0) {
		}
		char inChar3 = (char) SerialUSB.read();

		switch (inChar3) {
		case 'p': {
			SerialUSB.printf("pKp = ?");
			while (SerialUSB.available() == 0) {
			}
			pKp = get_a_float_value();
			SerialUSB.printf("new pKp = ");
			SerialUSB.printf("%0.2f\n", pKp);
			SerialUSB.printf("");
		}
			break;
		case 'i': {
			SerialUSB.printf("pKi = ?");
			while (SerialUSB.available() == 0) {
			}
			pKi = get_a_float_value();
			SerialUSB.printf("new pKi = ");
			SerialUSB.printf("%0.2f\n", pKi);
			SerialUSB.printf("");
		}
			break;
		case 'd': {
			SerialUSB.printf("pKd = ?");
			while (SerialUSB.available() == 0) {
			}
			pKd = get_a_float_value();
			SerialUSB.printf("new pKd = ");
			SerialUSB.printf("%0.2f\n", pKd);
			SerialUSB.printf("");
		}
			break;
		case 'l': {
			SerialUSB.printf("pLPF = ?");
			while (SerialUSB.available() == 0) {
			}
			pLPF = get_a_float_value();
			pLPFa = exp(pLPF * -2 * 3.14159 / Fs);
			pLPFb = (1.0 - pLPFa);
			SerialUSB.printf("new pLPF = ");
			SerialUSB.printf("%0.2f\n", pLPF);
			SerialUSB.printf("\n");
		}
			break;
		case 'q': {
			quit = true;
			SerialUSB.printf("\n");
			SerialUSB.printf("done...");
			SerialUSB.printf("\n");
		}
		default: {
		}
			break;
		}
	}
}

void parameterEditv() {
	bool quit = false;
	while (!quit) {
		SerialUSB.printf("Edit velocity loop gains:");
		SerialUSB.printf("\n");
		SerialUSB.printf("p ----- vKp = ");
		SerialUSB.printf("%0.2f\n", vKp);
		SerialUSB.printf("i ----- vKi = ");
		SerialUSB.printf("%0.2f\n", vKi);
		SerialUSB.printf("d ----- vKd = ");
		SerialUSB.printf("%0.2f\n", vKd);
		SerialUSB.printf("l ----- vLPF = ");
		SerialUSB.printf("%0.2f\n", vLPF);
		SerialUSB.printf("q ----- quit");
		SerialUSB.printf("\n");

		while (SerialUSB.available() == 0) {
		}
		char inChar4 = (char) SerialUSB.read();

		switch (inChar4) {
		case 'p': {
			SerialUSB.printf("vKp = ?");
			while (SerialUSB.available() == 0) {
			}
			vKp = get_a_float_value();
			SerialUSB.printf("new vKp = ");
			SerialUSB.printf("%0.2f\n", vKp);
		}
			break;
		case 'i': {
			SerialUSB.printf("vKi = ?");
			while (SerialUSB.available() == 0) {
			}
			vKi = get_a_float_value();
			SerialUSB.printf("new vKi = ");
			SerialUSB.printf("%0.2f\n", vKi);
		}
			break;
		case 'd': {
			SerialUSB.printf("vKd = ?");
			while (SerialUSB.available() == 0) {
			}
			vKd = get_a_float_value();
			SerialUSB.printf("new vKd = ");
			SerialUSB.printf("%0.2f\n", vKd);
		}
			break;
		case 'l': {
			SerialUSB.printf("vLPF = ?");
			while (SerialUSB.available() == 0) {
			}
			vLPF = get_a_float_value();
			vLPFa = (exp(vLPF * -2 * 3.14159 / Fs));
			vLPFb = (1.0 - vLPFa) * Fs * 0.16666667;
			SerialUSB.printf("new vLPF = ");
			SerialUSB.printf("%0.2f\n", vLPF);
			SerialUSB.printf("");
		}
			break;
		case 'q': {
			quit = true;
			SerialUSB.printf("\n");
			SerialUSB.printf("done...");
			SerialUSB.printf("\n");
		}
			break;
		default: {
		}
			break;
		}
	}
}

void parameterEdito() {

	SerialUSB.printf("Edit other parameters:");
	SerialUSB.printf("\n");
	SerialUSB.printf("p ----- PA = ");
	SerialUSB.printf("%0.2f\n", PA);
	SerialUSB.printf("\n");

	while (SerialUSB.available() == 0) {
	}
	char inChar3 = (char) SerialUSB.read();

	switch (inChar3) {
	case 'p': {
		SerialUSB.printf("PA = ?");
		while (SerialUSB.available() == 0) {
		}
		PA = get_a_float_value();
		SerialUSB.printf("new PA = ");
		SerialUSB.printf("%0.2f\n", PA);
	}
		break;
	default: {
	}
		break;
	}
}

void hybridControl() {        //still under development

	static int missed_steps = 0;
	static float iLevel = 0.6; //hybrid stepping current level.  In this mode, this current is continuous (unlike closed loop mode). Be very careful raising this value as you risk overheating the A4954 driver!
	static float rSense = 0.15;

	if (yw < r - aps) {
		missed_steps -= 1;
	} else if (yw > r + aps) {
		missed_steps += 1;
	}

	output((0.1125 * (-(r - missed_steps))),
			((255 / 3.3) * (iLevel * 10 * rSense)));

}

void serialMenu() {
	SerialUSB.printf("");
	SerialUSB.printf("");
	SerialUSB.printf("----- Mechaduino 0.1 -----");
	SerialUSB.printf("Firmware: ");
	SerialUSB.printf(firmware_version);
	SerialUSB.printf("Identifier: ");
	SerialUSB.printf(identifier);
	SerialUSB.printf("");
	SerialUSB.printf("Main menu");
	SerialUSB.printf("");
	SerialUSB.printf(" s  -  step");
	SerialUSB.printf(" d  -  dir");
	SerialUSB.printf(" p  -  printf angle");
	SerialUSB.printf("");
	SerialUSB.printf(" c  -  write new calibration table");
	SerialUSB.printf(" e  -  check encoder diagnositics");
	SerialUSB.printf(" q  -  parameter query");
	SerialUSB.printf("");
	SerialUSB.printf(" x  -  position mode");
	SerialUSB.printf(" v  -  velocity mode");
	SerialUSB.printf(" x  -  torque mode");
	SerialUSB.printf("");
	SerialUSB.printf(" y  -  enable control loop");
	SerialUSB.printf(" n  -  disable control loop");
	SerialUSB.printf(" r  -  enter new setpoint");
	SerialUSB.printf("");
	SerialUSB.printf(" j  -  step response");
	SerialUSB.printf(
			" k  -  edit controller gains -- note, these edits are stored in volatile memory and will be reset if power is cycled");
	SerialUSB.printf(" g  -  generate sine commutation table");
	SerialUSB.printf(" m  -  printf main menu");
// SerialUSB.printf(" f  -  get max loop frequency");
	SerialUSB.printf("\n");
}
void sineGen() {
	int temp;
	SerialUSB.printf("");
	SerialUSB.printf(
			"The sineGen() function in Utils.cpp generates a sinusoidal commutation table.");
	SerialUSB.printf(
			"You can experiment with different commutation profiles by modifying this table.");
	SerialUSB.printf(
			"The below table should be copied into sine_1 in Parameters.cpp.");
	SerialUSB.printf("");
	HAL_Delay(3000);
	SerialUSB.printf("printfing sine look up table:...");
	SerialUSB.printf("");
	for (int x = 0; x <= 3600; x++) {
		temp = round(
				1024.0 * sin((3.14159265358979 * ((x * 0.1 / 180.0) + 0.25))));
		SerialUSB.printf("%0.2f\n", temp);
		SerialUSB.printf(", ");
	}
}

void stepResponse() {     // not done yet...
	SerialUSB.printf("");
	SerialUSB.printf("--------------------------------");
	SerialUSB.printf("");
	SerialUSB.printf("Get ready for step response!");
	SerialUSB.printf("Close Serial Monitor and open Tools>>Serial Plotter");
	SerialUSB.printf("You have 10 seconds...");
	enableTCInterrupts();     //start in closed loop mode
//mode = 'x';
	r = 0;
	HAL_Delay(1000);
	SerialUSB.printf("9...");
	HAL_Delay(1000);
	SerialUSB.printf("8...");
	HAL_Delay(1000);
	SerialUSB.printf("7...");
	HAL_Delay(1000);
	SerialUSB.printf("6...");
	HAL_Delay(1000);
	SerialUSB.printf("5...");
	HAL_Delay(1000);
	SerialUSB.printf("4...");
	HAL_Delay(1000);
	SerialUSB.printf("3...");
	HAL_Delay(1000);
	SerialUSB.printf("2...");
	HAL_Delay(1000);
	SerialUSB.printf("1...");
	HAL_Delay(1000);
	printf_yw = true;
	HAL_Delay(100);
	r = 97.65; /// choose step size as you like, 97.65 gives a nice plot since 97.65*1024 = 10,000
	HAL_Delay(400);
	printf_yw = false;
	r = 0;
	HAL_Delay(500);
	disableTCInterrupts();

}

void moveRel(float pos_final, int vel_max, int accel) {

//Use this function for slow relative movements in closed loop position mode
//
// This function creates a "trapezoidal speed" trajectory (constant accel, and max speed, constant decel);
// It works pretty well, but it may not be perfect
//
// pos_final is the desired position in degrees
// vel_max is the max velocity in degrees/second
// accel is the max accel in degrees/second^2
//
//Note that the actual max velocity is limited by the execution speed of all the math below.
//Adjusting dpos (delta position, or step size) allows you to trade higher speeds for smoother motion
//Max speed with dpos = 0.225 degrees is about 180 deg/sec
//Max speed with dpos = 0.45 degrees is about 360 deg/sec

	float pos = 0;
	float dpos = 0.45; // "step size" in degrees, smaller is smoother, but will limit max speed, keep below stepper step angle
	float vel = 0;      //
	float vel_1 = 0;
	int start = micros(); //for debugging

	float accel_x_dpos = accel * dpos;  // pre calculate
	float dpos_x_1000000 = dpos * 1000000.0; // pre calculate

	float pos_remaining = pos_final - pos;
	unsigned long dt = 0;
	unsigned long t = micros();
	unsigned long t_1 = t;

	float r0 = r;  //hold initial setpoint

// Assume we're decelerating and calculate speed along deceleration profile

	while (_abs(pos_remaining) > (dpos / 2)) { //(may not actually reach exactly so leave some margin

		if (pos_remaining > 0)        // clockwise
			vel = sqrt(2.0 * pos_remaining * accel);
		else
			// counter clockwise
			vel = -sqrt(2.0 * -pos_remaining * accel);

		if (vel > vel_1) // Check if we actually need to accelerate in  clockwise direction
				{

			if (vel_1 == 0)
				vel = sqrt(2.0 * accel_x_dpos);
			else
				vel = vel_1 + _abs(accel_x_dpos / vel_1);
			if (vel > vel_max)
				vel = vel_max;
		} else if (vel < vel_1) {
			// Need to accelerate in  counter clockwise direction
			if (vel_1 == 0)
				vel = -sqrt(2.0 * accel_x_dpos);
			else
				vel = vel_1 - _abs(accel_x_dpos / vel_1);
			if (vel < -vel_max)
				vel = -vel_max;
		}
		//  SerialUSB.printf(vel);

		dt = _abs(dpos_x_1000000 / vel);

		while (t < t_1 + dt) {           //wait calculated dt
			t = micros();
		}

		if (vel > 0)
			pos += dpos;        //update setpoint
		else if (vel < 0)
			pos -= dpos;
		r = r0 + pos;

		//SerialUSB.printf(micros()-start);
		//SerialUSB.printf(" , ");

		t_1 = t;
		vel_1 = vel;
		pos_remaining = pos_final - pos;

	}
	r = r0 + pos_final;
//SerialUSB.printf(micros()-start);

}

void moveAbs(float pos_final, int vel_max, int accel) {

//Use this function for slow absolute movements in closed loop position mode
//
// This function creates a "trapezoidal speed" trajectory (constant accel, and max speed, constant decel);
// It works pretty well, but it may not be perfect
//
// pos_final is the desired position in degrees
// vel_max is the max velocity in degrees/second
// accel is the max accel in degrees/second^2
//
//Note that the actual max velocity is limited by the execution speed of all the math below.
//Adjusting dpos (delta position, or step size) allows you to trade higher speeds for smoother motion
//Max speed with dpos = 0.225 degrees is about 180 deg/sec
//Max speed with dpos = 0.45 degrees is about 360 deg/sec

	float pos = r;
	float dpos = 0.225; // "step size" in degrees, smaller is smoother, but will limit max speed, keep below stepper step angle
	float vel = 0;      //
	float vel_1 = 0;
// int start = micros(); //for debugging

	float accel_x_dpos = accel * dpos;  // pre calculate
	float dpos_x_1000000 = dpos * 1000000.0; // pre calculate

	float pos_remaining = pos_final - pos;
	unsigned long dt = 0;
	unsigned long t = micros();
	unsigned long t_1 = t;

// Assume we're decelerating and calculate speed along deceleration profile

	while (_abs(pos_remaining) > (dpos / 2)) { //(may not actually reach exactly so leave some margin

		if (pos_remaining > 0)        // clockwise
			vel = sqrt(2.0 * pos_remaining * accel);
		else
			// counter clockwise
			vel = -sqrt(2.0 * -pos_remaining * accel);

		if (vel > vel_1) // Check if we actually need to accelerate in  clockwise direction
				{

			if (vel_1 == 0)
				vel = sqrt(2.0 * accel_x_dpos);
			else
				vel = vel_1 + _abs(accel_x_dpos / vel_1);
			if (vel > vel_max)
				vel = vel_max;
		} else if (vel < vel_1) {
			// Need to accelerate in  counter clockwise direction
			if (vel_1 == 0)
				vel = -sqrt(2.0 * accel_x_dpos);
			else
				vel = vel_1 - _abs(accel_x_dpos / vel_1);
			if (vel < -vel_max)
				vel = -vel_max;
		}
		//  SerialUSB.printf(vel);

		dt = _abs(dpos_x_1000000 / vel);

		while (t < t_1 + dt) {           //wait calculated dt
			t = micros();
		}

		if (vel > 0)
			pos += dpos;        //update setpoint
		else if (vel < 0)
			pos -= dpos;
		r = pos;

		//SerialUSB.printf(micros()-start);    //for debugging
		//SerialUSB.printf(" , ");

		t_1 = t;
		vel_1 = vel;
		pos_remaining = pos_final - pos;

	}
	r = pos_final;
//SerialUSB.printf(micros()-start);

}
void setpositionKp(float *P) {
	pKp = *P;
}
void setpositionKi(float *I) {
	pKi = *I;
}

void setpositionKd(float *D) {
	pKd = *D;
}

void test_encoder_calibrate() {
	float current_voltage = uMAX * 0.5;
	output_int(0, (1 * uMAX));
	int16_t max_step = whole_steps, e_y = 0;
	uint32_t encode_read = 0, encode_read_shf = 0, start_up_y = 0;
	int16_t lookup_dif = 0;
	for (int i = 0; i < max_step; i++) {
		encode_read = read_Encoder();
		encode_read_shf = encode_read >> SUBDIVIDE_UINT16_T_SHIFT;
		y = lookup[encode_read_shf]; //read encoder and lookup corrected angle in calibration lookup table
		lookup_dif = encode_read & SUBDIVIDE_UINT16_T_SHIFT_MASK;
		y = y + lookup_dif * default_ratio;
		if (i == 0) {
			start_up_y = y;
//			y = 0;
		} else {
//			y = y - start_up_y;

			e_y = (y - y_1);
			if (e_y < -half_steps)
				wrap_count += 1; //Check if we've rotated more than a full revolution (have we "wrapped" around from 359 degrees to 0 or ffrom 0 to 359?)
			else if (e_y > half_steps)
				wrap_count -= 1;

			yw = (y + (whole_steps * wrap_count)) - start_up_y; //yw is the wrapped angle (can exceed one revolution)

		}
		y_1 = y;
		SerialUSB.printf("s %d ,ey %d y %d yw %d wc %d er %d erf %d lf %d\n", i,
				e_y, y, yw, wrap_count, encode_read, encode_read_shf,
				lookup_dif);
		output_int(i * step_2_angle, (1 * uMAX));
	}
}

//TODO need to implement
void emergency_stop(char enable) {
	SerialUSB.printf("Emergency Stop! %d\n", enable);
	if (enable) {
		myAnanasStete.emergency_stop = 1;
		//TODO need to inform other device to stop through CAN
		//First need to register all device online
	} else {
		myAnanasStete.emergency_stop = 0;
	}
}

/*
 *	G0 X(moter index) F(feadrate p/s) P(target point)
 *	// G1 Drive motor immediately
 *	G1 T(time) X(moter index) F(feadrate p/s) P(target point)
 *	// G0 Drive motor with time limited
 *	G2 R(target needed) X(moter index) F(feadrate p/s) P(target point)
 *	//G2 Drive motor with target reach
 *	G28 go home
 *	M0 //print debug state
 *	M1 D(direction) E(enable direction) S(enble mode) 
 	C(care_enable_state) // control dir enable and enable mode
 *	M2 S(current) //set motor current
 *	M3 S(can baudrate) //set can baudrate
 *	M4 S(ID) //set mode ID
 *	M5 S(sub devide) // set subdevide
 *	M6 test 485
 *	M7 S(target) F(feedrate) //same as G1 Drive immediately
 *	M8 onestep test
 *	M9 onestep change direction
 *	M10 calibrate encoder
 *	M11 P I D //set motor feedback PID
 *	M12 print calibrate table
 *	M13 check is_reach_time flag
 *	M14 exit is_reach_time waiting
 *  M15 R(endstop reverse) O(set_in_or_out)
 *	M114 print endstop state
 *	M501 reload eeprom
 *	M500 store eeprom
 *	M502 load default eeprom
 *	M666 test encoder calibreate
 *	M999 enter dfu mode to load new flash
 *
 *	other command with lower case
 */

void process_command() {
//	if (getcommand() == false) {
//		return;
//	}
	
	
	//确认缓冲区是否有数据
	if (check_and_store_cmd() == false) 
	{
		return;		//没有命令在缓冲区 --- 结束函数
	}

	long code_valuel;
	long code_valuel1;
	float code_valuef;
	float code_valuef1;
//	float code_valuef2;
	if (code_seen('G')) 
	{ 
		if (false == is_reach_time) {		//电机还在执行运动当中
			//there is an uncompleted movement;
			return;
		}
		
		
		uint16_t deviceID = 0;
		long position = 0;
		long feedrate = 0;
		switch ((int) code_value()) {
		case 0:
			if (code_seen('X')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					deviceID = code_valuel;
				} else {
					SerialUSB.printf("ERROR:device < 0\n");
					break;
				}

				if (code_seen('F')) 
				{
					feedrate = code_value_long();
					// feedrate
					if (deviceID == device_id) 		
					{
						if (feedrate > 0) 
						{
							r_v = float(feedrate) / Fs;		//转化F速度值
						} 
						else 
						{
							r_v = 1;
						}
					} 
					else 		//命令中的ID对不上，将数据使用can发送出去
					{
						send_velocity_through_can(&hcan, deviceID, feedrate);
					}
				}

				if (code_seen('P')) 
				{
					position = code_value_long();
					//position
					if (deviceID == device_id) {
						is_reach_target = false;
						r_t = position;
						set_input_mode('C');
					} else {
						send_positon_through_can(&hcan, deviceID, position, 0);
					}
				}

			}
			SerialUSB.printf("G0 ID %d P %d F %d T %d\n", deviceID, position,
					feedrate, travel_time);
			break;
		case 1:
			if (false == is_reach_time) {
				//has not reach the time
				//ignore this command
				return;
			}
			if (code_seen('X')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					deviceID = code_valuel;
				} else {
					SerialUSB.printf("ERROR:device < 0\n");
					break;
				}
				if (code_seen('T')) {
					code_valuel1 = code_value_long();
					if (code_valuel1) {
						if (deviceID == device_id) {
							travel_time = code_valuel1;
							is_reach_time = false;
						}
					}
				} else {
					SerialUSB.printf("Error G1 with no time setting\n");
					break;
				}

				if (code_seen('F')) {
					feedrate = code_value_long();
					// feedrate
					if (deviceID == device_id) {
						if (feedrate > 0) {
							r_v = float(feedrate) / Fs;
						} else {
							r_v = 1;
						}
					} else {
						send_velocity_through_can(&hcan, deviceID, feedrate);
					}
				}

				if (code_seen('P')) {
					position = code_value_long();
					//position
					if (deviceID == device_id) {
						is_reach_target = false;		//没有到达目标位置
						r_t = position;
						set_input_mode('C');			//不知道干嘛的
					} else {
						send_positon_through_can(&hcan, deviceID, position, 0);
					}
				}

			}
			SerialUSB.printf("G1 ID %d P %d F %d T %d\n", deviceID, position,
					feedrate, travel_time);
			break;

		case 2:
			//TODO need to handle a table with states of other stepper
			//Need FreeRTOS
			//Need to finish the emergency funciton
			if (false == is_reach_target) {
				//ignore this command
				return;
			}
			if (code_seen('R')) {

			} else {
				SerialUSB.printf("ERROR:G2 need R\n");
				break;
			}

			if (code_seen('X')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					deviceID = code_valuel;
				} else {
					SerialUSB.printf("ERROR:device < 0\n");
					break;
				}

				if (code_seen('F')) {
					feedrate = code_value_long();
					// feedrate
					if (deviceID == device_id) {
						//Care reach target
						is_reach_target = false;
						if (feedrate > 0) {
							r_v = float(feedrate) / Fs;
						} else {
							r_v = 1;
						}
					} else {
						send_velocity_through_can(&hcan, deviceID, feedrate);
					}
				}

				if (code_seen('P')) {
					position = code_value_long();
					//position
					if (deviceID == device_id) {
						is_reach_target = false;
						r_t = position;
						set_input_mode('C');
					} else {
						send_positon_through_can(&hcan, deviceID, position, 1);
					}
				}

			}
			SerialUSB.printf("G2 ID %d P %d F %d T %d R\n", deviceID, position,
					feedrate, travel_time);
			break;
		case 28:
			SerialUSB.printf("Go Home\n");
			input_mode = 'C';
			read_endstop();
			if (code_seen('X')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					deviceID = code_valuel;
				} else {
					SerialUSB.printf("ERROR:device < 0\n");
					break;
				}
			}

			if (code_seen('D')) {
				code_valuel = code_value_long();
				code_valuef = 1000;
				if (code_seen('F')) {
					code_valuel1 = code_value();
				}

				if (deviceID == device_id) {
					if (code_valuel == 1) {
						code_valuel1 = -code_valuel1;
					}
					if (code_seen('S')) {
						SerialUSB.printf("Use Soft Endstop\n");
						code_valuef1 = iMAX;
						SerialUSB.printf("Half Current %.2f", code_valuef1 / 2);
						setcurrent(code_valuef1 / 2); //half the current
						code_valuel = travel_to_end(code_valuel, 1,
								code_valuel1, 10000);
						SerialUSB.printf("Recover current %.2f", code_valuef1);
						setcurrent(code_valuef1); //recover the current
					} else {
						code_valuel = travel_to_end(code_valuel, 0,
								code_valuel1, 10000);
					}
					if (code_valuel <= 0) {
						SerialUSB.printf("Home Fail with return %d\n",
								code_valuel);
						break;
					}
					//reset controller
					reset_controller();
					HAL_Delay(500);
					//run back for a while
					move_back(-code_valuel1, 1000);
				} else {
					if (code_seen('S')) { //use soft end stop
						send_go_home_can(&hcan, deviceID, code_valuel, 1,
								code_valuel1, 10000);
					} else {
						send_go_home_can(&hcan, deviceID, code_valuel, 0,
								code_valuel1, 10000);
					}
				}
			}
			break;
		case 29:
			SerialUSB.printf("reset device\n");
			if (code_seen('X')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					deviceID = code_valuel;
				} else {
					SerialUSB.printf("ERROR:device < 0\n");
					break;
				}

				if (deviceID == device_id) {
					disableTCInterrupts();
					reset_controller();
					r_t = 0;
					r = 0;
					is_reach_target = true;
					is_reach_time = true;
					enableTCInterrupts();
				} else {
					reset_position_and_velocity(&hcan, deviceID);
				}
			} else {
				SerialUSB.printf("need to give device ID\n");
			}

			break;
		case 30:
			SerialUSB.printf("emergency stop\n");
			if (code_seen('X')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					deviceID = code_valuel;
				} else {
					SerialUSB.printf("ERROR:device < 0\n");
					break;
				}
			} else {
				SerialUSB.printf("need to give device ID\n");
			}

			if (deviceID == device_id) {
				if (code_seen('S')) {
					myAnanasStete.emergency_stop = 1;
				} else {
					myAnanasStete.emergency_stop = 0;
				}
			} else {
				if (code_seen('S')) {
					emergency_stop(&hcan, deviceID, 1);
				} else {
					emergency_stop(&hcan, deviceID, 0);
				}
			}
			break;
		default:
			SerialUSB.printf("Unknow G code\n");
			break;
		}
	} else //
	if (code_seen('M')) {
		switch ((int) code_value()) {
		case 0:
			SerialUSB.printf("Print Debug Msg.\n");
			SerialUSB.printf("Pulse Input Trigged\n");
			SerialUSB.printf("1:%d 2:%d 3:%d\n", trigger_time[0],
					trigger_time[1], trigger_time[2]);
			SerialUSB.printf("PinState En %d Dir %d Stp %d\n",
					HAL_GPIO_ReadPin(Enable_IN_GPIO_Port,
					Enable_IN_Pin),
					HAL_GPIO_ReadPin(Dir_IN_GPIO_Port, Dir_IN_Pin),
					HAL_GPIO_ReadPin(Step_IN_GPIO_Port, Step_IN_Pin));

			SerialUSB.printf("485 data get %d err %d\n", num_485_rx,
					num_485_error);
			SerialUSB.printf("CAN data get %d rere %d err %d\n", num_can_rx,
					num_can_re_receive, can_error_time);
			SerialUSB.printf("Encoder %d Target %.2f abs_e %d\n", yw, r ,abs_e);
			break;
		case 1:
			if (code_seen('D')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					dir_direction = code_valuel;
					dirInterrupt();
				}
			}
			if (code_seen('E')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					enable_direction = code_valuel;
					enableInterrupt();
				}
			}
			if (code_seen('S')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					enable_mode = code_valuel;
					enableInterrupt();
				}
			}
			if (code_seen('C')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					care_enable_state = code_valuel;
				}
			}
			SerialUSB.printf(
					"Dir_Dir %d Enable_Dir %d En_mode %d \n"
					" care_enable %d\n",
					dir_direction, enable_direction, enable_mode,
					care_enable_state);
			break;
		case 2:
			if (code_seen('S')) {
				code_valuef = code_value();
				if (code_valuef > 0) {
					setcurrent(code_valuef);
				}
			}
			SerialUSB.printf("Max Current %.2f\n", iMAX);
			break;
		case 3:
			if (code_seen('S')) {
				code_valuel = code_value_long();
				if (code_valuel > 0) {
					if (CAN_GetBaudRateNum(code_valuel) != BAUDRATE_INVALID) {
						canBaudRate = code_valuel;
						CAN_Configuration(canBaudRate);
					}
				}
			}
			SerialUSB.printf("CanBaudRate %d\n", canBaudRate);
			break;
		case 4:
			if (code_seen('S')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					device_id = code_valuel;
					device_id_relatic = device_id >> 2;
					device_id_relatic_left = (device_id & 0x0003) << 1;
				}
			}
			SerialUSB.printf("Device ID %d\n", device_id);
			break;
		case 5:
			if (code_seen('S')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					set_devide(code_valuel);
				}
			}
			SerialUSB.printf("Sudevide Index %d Subdevide %.2f %d\n",
					subdevide_choice, 128.0 / subdevide, subdevide);
			break;
		case 6:
			dir_485.set();
//			HAL_Delay(1000);
			Serial485.printf("RS485 TEST %s\n",cmdbuffer);
			HAL_Delay(100);
			dir_485.reset();
			// SerialUSB.printf("Test 485!\n");
			break;
		case 61:
			for (int i = 0; i < 1000; i++) {
				HAL_GPIO_TogglePin(Encoder_B_GPIO_Port, Encoder_B_Pin);
				HAL_Delay(1);
				HAL_GPIO_TogglePin(Encoder_A_GPIO_Port, Encoder_A_Pin);
			}
			break;
		case 7:
			if (code_seen('S')) {
				code_valuel = code_value_long();
				r_t = code_valuel;
			}
			if (code_seen('F')) {
				code_valuel = code_value_long();
				if (code_valuel > 0) {
					r_v = float(code_valuel) / Fs;
				} else {
					r_v = 1;
				}
			}

			set_input_mode('C');
			SerialUSB.printf("R_t %d R_v %f\n", r_t, r_v);
			break;
		case 8:
			oneStep();
			break;
		case 9:
			if (dir) {
				dir = false;
			} else {
				dir = true;
			}
			break;
		case 10:
			calibrate_int();
			break;
		case 11:
			if (code_seen('P')) {
				code_valuef = code_value();
				setpositionKp(&code_valuef);
			}
			if (code_seen('I')) {
				code_valuef = code_value();
				setpositionKi(&code_valuef);
			}
			if (code_seen('D')) {
				code_valuef = code_value();
				setpositionKd(&code_valuef);
			}
			SerialUSB.printf("Positon Kp %.7f Ki %.7f Kd %.7f\n", pKp, pKi,
					pKd);
			break;
		case 12:
			printlockup();
			break;
		case 13:
			SerialUSB.printf("Travle State Time %d\n", is_reach_time);
			break;
		case 14:
			is_reach_time = true;
			SerialUSB.printf("Force End Travel Time\n");
			break;
		case 15:
			if (code_seen('R')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					hardEndstopReversion = code_valuel;
				}
			}
			if (code_seen('O')) {
				code_valuel = code_value_long();
				if (code_valuel >= 0) {
					endstop_in_or_out = code_valuel;
				}
			}
			SerialUSB.printf(
					"endsrop_reverse %d in or out %d\n",
					hardEndstopReversion,
					endstop_in_or_out);
			break;
		case 114:
			read_endstop();
			SerialUSB.printf("Stop Key Trigger up %d down %d p %d\n",
					myAnanasStete.upStopState, myAnanasStete.downStopState, yw);
			break;
		case 501:
			c_eep::reload();
			SerialUSB.printf("Reload EEProm!\n");
			break;
		case 500:
			c_eep::write();
			SerialUSB.printf("Store EEProm!\n");
			break;
		case 502:
			c_eep::loadDef();
			SerialUSB.printf("Set to Default Date!\n");
			break;
		case 666:
			test_encoder_calibrate();
			break;
		case 999:
			boot_to_def();
			break;
		case 1000:
			//emergency stop
			if (code_seen('S')) {
				code_valuel = code_value();
				if (code_valuel == 0) {
					emergency_stop(code_valuel);
				}
			}
			emergency_stop(1); //enable emergency stop
			break;
		default:
			SerialUSB.printf("UnKonw M Code!\n");
			break;
		}
	} else if (code_seen('p')) {             //printf
		printf_angle();
	} else if (code_seen('s')) {             //step
		oneStep();
		printf_angle();
	} else if (code_seen('d')) {             //dir
		if (dir) {
			dir = false;
		} else {
			dir = true;
		}
	} else
#ifdef SUBDIVIDE_FLOAT_ANGLE_ENABLE
	if (code_seen('w')) {                //old command
		calibrate();//cal routine
	} else

	if (code_seen('c')) {
		calibrate();                //cal routine
	} else
#else
	if (code_seen('c')) {
		calibrate_int();           //cal routine
	} else
#endif
	if (code_seen('e')) {
		readEncoderDiagnostics();   //encoder error?
	} else if (code_seen('y')) {
		enableTCInterrupts();      //enable closed loop
	} else if (code_seen('n')) {
		disableTCInterrupts();      //disable closed loop
	} else if (code_seen('x')) {
		mode = 'x';           //position loop
	} else if (code_seen('v')) {
		mode = 'v';           //velocity loop
	} else if (code_seen('t')) {
		mode = 't';           //torque loop
	} else if (code_seen('h')) {               //hybrid mode
		mode = 'h';
	} else if (code_seen('g')) {
		sineGen();
	} else if (code_seen('m')) {
		serialMenu();
	} else if (code_seen('j')) {
		stepResponse();
	}
	SerialUSB.printf("CMD Process %s\n", cmdbuffer);
	memset(cmdbuffer, 0, sizeof(MAX_CMD_SIZE));
//	cmdbuffer[0] = 0;//clear process buffer

	//there are new commands
	//move rear to next command
	if ((buffers_rear) != buffers_head) {
		//there are some sites in the buffers
		MOVE_BUFFERS_INDEX(buffers_rear);
		cmdbuffer = cmdbuffers[buffers_rear];
	}
}

