/*
 * Ananas_Motion.cpp
 *
 *  Created on: 2018��10��30��
 *      Author: Dark
 */

#include "Ananas_Motion.h"
#include "can_driver.h"
#include "Utils.h"
#include "Controller.h"

uint16_t device_id = 0;
uint8_t device_id_relatic = 0;
uint8_t device_id_relatic_left = 0;

uint16_t subdevide_list[] = { 1, 2, 4, 8, 16 };
uint16_t subdevide_choice = SUBDEVIDE_16; //SUBDEVIDE_128;
uint16_t subdevide = subdevide_list[subdevide_choice];

float iMMMax = MAX_MAX_CURRENT; //������
float iMMax = (4095 / 3.3)
		* ((float(iMMMax) - iMAX) * 10 * rSense)/CURRENT_DEGREE;
volatile int uMAX_control = uMAX;

uint32_t canBaudRate = 500000;

volatile long can_target = 0;
long can_speed = 0;

uint16_t relative_canid = 0;
int16_t relative_value = 0;

#define NUM_ABSOLUTE_VALUE 2
#define NUM_RELATIVE_VALUE 4

#define RUN_STEP_NUM 5
#define MAX_STEP_ERROR_ALLOW 10
long positionRun[RUN_STEP_NUM] = { 0, -40000, 0, -40000, 0 };
uint8_t RunIndex = 0;
long step_num_error = 0;

void reset_current_data();

void set_devide(uint8_t chooce_devide) {
	if (chooce_devide > SUBDEVIDE_8) {
		return;
	}
	subdevide_choice = chooce_devide;
	subdevide = subdevide_list[subdevide_choice];
}

void motion_parameter_reset() {
	device_id = 0;
	subdevide_choice = SUBDEVIDE_128;
	subdevide = subdevide_list[subdevide_choice];

	pKp = 0.01;
	pKi = 0.005;
	pKd = 0.01;

	iMAX = 1.0;
	iMMMax = MAX_MAX_CURRENT;

	reset_current_data();

	canBaudRate = 500000;
}

void reset_current_data() {
	iMMax = (4095 / 3.3)
			* ((float(iMMMax) - iMAX) * 10 * rSense)/CURRENT_DEGREE;
	uMAX = (4095 / 3.3) * (iMAX * 10 * rSense);
}

void current_control_For_Pulse(uint32_t error, uint32_t low_error_count) {

	if (low_error_count > HALF_CURRENT_LOW_ERROR_TIME) {
		uMAX_control = uMAX / 2;
		return;
	} else {
		uMAX_control = uMAX;
	}

//	if (error > MAX_ERROR_FOR_PULSE) {
//		uMAX_control = uMAX + iMMax * CURRENT_DEGREE;
//	} else {
//		uMAX_control = uMAX + iMMax * (error / EACH_ERROR_FOR_PULSE);
//	}
}

void current_control_For_CAN(uint32_t error, uint32_t low_error_count) {

	if (low_error_count > HALF_CURRENT_LOW_ERROR_TIME) {
		uMAX_control = uMAX / 2;
		return;
	}
	if (error > MAX_ERROR_FOR_PULSE) {
		uMAX_control = uMAX + iMMax * CURRENT_DEGREE / 2;
	} else {
		uMAX_control = uMAX + iMMax * (error / EACH_ERROR_FOR_CAN);
	}

}

void process_motion(CAN_HandleTypeDef* hcan) {
	if (hcan->pRxMsg->IDE == CAN_ID_STD) {
		set_input_mode('C');
		if (hcan->pRxMsg->StdId == CAN_SYC_MOVE_ID1 + device_id) {
			//�����˶�λ��
			if (hcan->pRxMsg->DLC == 5) {
				if (hcan->pRxMsg->Data[4]) {
					//TODO care target
					is_reach_target = false;
				}

				is_reach_target = false; //is_reach_target should be run
				can_target = (hcan->pRxMsg->Data[0] << 24)
						+ (hcan->pRxMsg->Data[1] << 16)
						+ (hcan->pRxMsg->Data[2] << 8)
						+ (hcan->pRxMsg->Data[3]);
				r_t = can_target;

			} else if (hcan->pRxMsg->DLC == 8) { //home process
				char buf[64];
				memset(buf, 0, 64); //set all data to zero
				long feedrate = (hcan->pRxMsg->Data[0] << 24)
						+ (hcan->pRxMsg->Data[1] << 16)
						+ (hcan->pRxMsg->Data[2] << 8)
						+ (hcan->pRxMsg->Data[3]);
				long timeout = (hcan->pRxMsg->Data[6] << 8)
						+ (hcan->pRxMsg->Data[7]);
				if (hcan->pRxMsg->Data[5] == 1) { //use soft endstop
					sprintf(buf, "G28 S X%d F%d D%d\n", device_id, feedrate,
							hcan->pRxMsg->Data[4]);
				} else { //not use soft endstop
					sprintf(buf, "G28 X%d F%d D%d\n", device_id, feedrate,
							hcan->pRxMsg->Data[4]);
				}
				uint32_t len = strlen(buf);
				SerialUSB.rxCallback((uint8_t*) buf, &len);

			} else if (hcan->pRxMsg->DLC == 1) { // emergency stop
				// TODO Reset Position
				yw = r = r_t = 0;
			}
		} else if (hcan->pRxMsg->StdId == CAN_CONTROLID + device_id) {
			//����һ���ٶ�
			if (hcan->pRxMsg->DLC == 4) {
				can_speed = (hcan->pRxMsg->Data[0] << 24)
						+ (hcan->pRxMsg->Data[1] << 16)
						+ (hcan->pRxMsg->Data[2] << 8)
						+ (hcan->pRxMsg->Data[3]);
				r_v = float(can_speed) / Fs;
			} else if (hcan->pRxMsg->DLC == 2) {
				// emergency stop
				if(hcan->pRxMsg->Data[0] == 1){
					myAnanasStete.emergency_stop = 1;
				}else{
					myAnanasStete.emergency_stop = 0;
				}
			} else if (hcan->pRxMsg->DLC == 1) {
				//reset device
				disableTCInterrupts();
				reset_controller();
				r_t = 0;
				r = 0;
				is_reach_target = true;
				is_reach_time = true;
				enableTCInterrupts();
			}
		} else if (hcan->pRxMsg->StdId
				== CAN_SYC_MOVE_ID2 + (device_id_relatic)) {
			//�������λ��
			relative_canid = device_id_relatic_left;
			relative_value = (hcan->pRxMsg->Data[relative_canid] << 8)
					+ (hcan->pRxMsg->Data[relative_canid + 1]);
			can_target += relative_value;
			r_t = can_target;
		}
	}
}

void process_Step() {
	if (RunIndex >= RUN_STEP_NUM) {
		return;
	}
	r = positionRun[RunIndex];
	step_num_error = abs(yw - positionRun[RunIndex]);
	if (step_num_error < MAX_STEP_ERROR_ALLOW) {
		RunIndex++;

	}
}
//Send CAN to sub ones

void send_positon_through_can(CAN_HandleTypeDef* hcan, uint8_t ID, long value,
		uint8_t care_target) {
	hcan->pTxMsg->IDE = CAN_ID_STD;
	hcan->pTxMsg->RTR = CAN_RTR_DATA;
	hcan->pTxMsg->StdId = CAN_SYC_MOVE_ID1 + ID;
	hcan->pTxMsg->DLC = 5;
	hcan->pTxMsg->Data[0] = uint8_t((value >> 24) & 0xFF);
	hcan->pTxMsg->Data[1] = uint8_t((value >> 16) & 0xFF);
	hcan->pTxMsg->Data[2] = uint8_t((value >> 8) & 0xFF);
	hcan->pTxMsg->Data[3] = uint8_t((value) & 0xFF);

	hcan->pTxMsg->Data[4] = care_target;
	int resendtime = 0;
	while (HAL_CAN_Transmit(hcan, 1000) != HAL_OK) {
		resendtime++;
		if (resendtime > CAN_RESENT_TIME) {
			break;
		}
	}
}

void send_velocity_through_can(CAN_HandleTypeDef* hcan, uint8_t ID,
		long value) {
	hcan->pTxMsg->IDE = CAN_ID_STD;
	hcan->pTxMsg->RTR = CAN_RTR_DATA;
	hcan->pTxMsg->StdId = CAN_CONTROLID + ID;
	hcan->pTxMsg->DLC = 4;
	//send target
	hcan->pTxMsg->Data[0] = uint8_t((value >> 24) & 0xFF);
	hcan->pTxMsg->Data[1] = uint8_t((value >> 16) & 0xFF);
	hcan->pTxMsg->Data[2] = uint8_t((value >> 8) & 0xFF);
	hcan->pTxMsg->Data[3] = uint8_t((value) & 0xFF);

	int resendtime = 0;
	while (HAL_CAN_Transmit(hcan, 1000) != HAL_OK) {
		resendtime++;
		if (resendtime > CAN_RESENT_TIME) {
			break;
		}
	}

}

void reset_position_and_velocity(CAN_HandleTypeDef* hcan, uint8_t ID) {
	hcan->pTxMsg->IDE = CAN_ID_STD;
	hcan->pTxMsg->RTR = CAN_RTR_DATA;
	hcan->pTxMsg->StdId = CAN_CONTROLID + ID;
	hcan->pTxMsg->DLC = 1;
	hcan->pTxMsg->Data[0] = 0x00;
	int resendtime = 0;
	while (HAL_CAN_Transmit(hcan, 1000) != HAL_OK) {
		resendtime++;
		if (resendtime > CAN_RESENT_TIME) {
			break;
		}
	}
}

void emergency_stop(CAN_HandleTypeDef* hcan, uint8_t ID,uint8_t enable) {
	hcan->pTxMsg->IDE = CAN_ID_STD;
	hcan->pTxMsg->RTR = CAN_RTR_DATA;
	hcan->pTxMsg->StdId = CAN_CONTROLID + ID;
	hcan->pTxMsg->DLC = 2;
	hcan->pTxMsg->Data[0] = enable;
	hcan->pTxMsg->Data[1] = 0x01;
	int resendtime = 0;
	while (HAL_CAN_Transmit(hcan, 1000) != HAL_OK) {
		resendtime++;
		if (resendtime > CAN_RESENT_TIME) {
			break;
		}
	}
}

void send_go_home_can(CAN_HandleTypeDef* hcan, uint8_t ID, uint8_t dir,
		uint8_t isSoftEndStop, long feedrate, long timeout) {
	hcan->pTxMsg->IDE = CAN_ID_STD;
	hcan->pTxMsg->RTR = CAN_RTR_DATA;
	hcan->pTxMsg->StdId = CAN_SYC_MOVE_ID1 + ID;
	hcan->pTxMsg->DLC = 8;
	hcan->pTxMsg->Data[0] = uint8_t((feedrate >> 24) & 0xFF);
	hcan->pTxMsg->Data[1] = uint8_t((feedrate >> 16) & 0xFF);
	hcan->pTxMsg->Data[2] = uint8_t((feedrate >> 8) & 0xFF);
	hcan->pTxMsg->Data[3] = uint8_t((feedrate) & 0xFF);
	hcan->pTxMsg->Data[4] = dir;
	hcan->pTxMsg->Data[5] = isSoftEndStop;
	hcan->pTxMsg->Data[6] = uint8_t((timeout >> 8) & 0xFF);
	hcan->pTxMsg->Data[7] = uint8_t((timeout) & 0xFF);

	int resendtime = 0;
	while (HAL_CAN_Transmit(hcan, 1000) != HAL_OK) {
		resendtime++;
		if (resendtime > CAN_RESENT_TIME) {
			break;
		}
	}
}

/**
 * move to end usr by home
 * @param dir 0 for up endstop  1 for down endstop
 * @param isSoftEndStop 0 for hardware endstop 1 for software endstop
 * @param feedrate
 * @param timeout
 * @return
 */
int travel_to_end(uint8_t dir, uint8_t isSoftEndStop, float feedrate,
		int timeout) {
	float step = feedrate / 1000;

	myAnanasStete.care_stop = 1; //prepare to care endstop
	myAnanasStete.homeDir = dir;
	if (isSoftEndStop) {
		myAnanasStete.useSoftEndstop = 1;
		myAnanasStete.softEndstopTargeted = 0;
		max_soft_endstop_care_error = 10 * step;
		while (myAnanasStete.softEndstopTargeted == 0) {
			r += step; //drive the motor
			HAL_Delay(1);
			timeout--;
			if (0 == timeout) {
				return 0;
			}
		}
	} else {
		//not use soft end stop
		myAnanasStete.useSoftEndstop = 0;
		while (true) {
			if (0 == dir) {
				if (false == hardEndstopReversion) { //charge endstop target direction
					if (myAnanasStete.upStopState == 1) {
						break;
					}
				} else {
					if (myAnanasStete.downStopState == 1) {
						break;
					}
				}
			} else {
				if (false == hardEndstopReversion) {
					if (myAnanasStete.downStopState == 1) {
						break;
					}
				} else {
					if (myAnanasStete.upStopState == 1) {
						break;
					}
				}
			}

			//care up endstop
			r += step; //drive the motor
			HAL_Delay(1);
			timeout--;
			if (0 == timeout) {
				return 0;
			}
		}
	}

	if (false == hardEndstopReversion) {
		if (0 == dir) {
			if (myAnanasStete.upStopState == 1) {
				return 1; //a correct endstop is trigged
			} else if (myAnanasStete.downStopState == 1) {
				return -2; // a wrong endstop is trigged
			}
		} else
		//care down endstop
		{
			if (myAnanasStete.downStopState == 1) {
				return 1; //a correct endstop is trigged
			} else if (myAnanasStete.upStopState == 1) {
				return -2; // a wrong endstop is trigged
			}
		}
	} else {
		if (1 == dir) {
			if (myAnanasStete.upStopState == 1) {
				return 1; //a correct endstop is trigged
			} else if (myAnanasStete.downStopState == 1) {
				return -2; // a wrong endstop is trigged
			}
		} else
		//care down endstop
		{
			if (myAnanasStete.downStopState == 1) {
				return 1; //a correct endstop is trigged
			} else if (myAnanasStete.upStopState == 1) {
				return -2; // a wrong endstop is trigged
			}
		}
	}

	if (myAnanasStete.softEndstopTargeted) {
		myAnanasStete.softEndstopTargeted = 0;
		return 1;
	}

	return -1;
}

void move_back(float feedrate, int timeout) {
	myAnanasStete.care_stop = 0; //stop care endstop
	float step = feedrate / 1000;
	while (timeout) {
		r += step; //drive the motor
		HAL_Delay(1);
		timeout--;
	}
}
