/*
 * Ananas_Dac.cpp
 *
 *  Created on: 2018��8��4��
 *      Author: Dark
 */

#include "cpp_serial.h"
#include "cpp_gpio.h"
#include "cpp_eep.h"
#include "Ananas_Dac.h"
#include "Ananas_Motion.h"
#include "cpp_usbSerial.h"
#include "Controller.h"
#include "Utils.h"
#include "Parameters.h"
#include "State.h"
#include "encoder.h"
#include "can_driver.h"
#include "test_hardware_temp.h"

#define ANANAS_VERSION "V1.1.0"

c_gpio state_led(led_GPIO_Port, led_Pin);
c_gpio error_led(Error_OUT_GPIO_Port, Error_OUT_Pin);
c_gpio dir_485(RS485_Dir_GPIO_Port, RS485_Dir_Pin);

c_serial Serial485(&huart1, 512, 512, IO_MODE_DMA);
//c_serial SerialUSB(&huart1, 1024, 1024, IO_MODE_DMA);
c_usbSerial SerialUSB(255, 1023);
uint32_t LEDdelayT;
uint32_t LEDblinkTime = 1000;
uint32_t reportTime;
uint32_t stateReportTime = 1000;

volatile uint32_t PID_time_per_second = 0;
long trigger_time[3] = { 0, 0, 0 };
long num_485_rx = 0;
long num_485_error = 0;

CanRxMsgTypeDef myRxMessage;
CanTxMsgTypeDef myTxMessage;
volatile uint8_t commandCanRxMsgFlag = 0;
uint8_t can_rearm_rx = 0;
long num_can_rx = 0;
long num_can_re_receive = 0;

void value_reset() {
	device_id_relatic = device_id >> 2;
	device_id_relatic_left = (device_id & 0x0003) << 1;
}

void Ananas_Init(void) {
	LEDdelayT = HAL_GetTick();
	c_eep::init();					//stm32内部EEPROM初始化（SPI）
	value_reset();					//有关设备ID的值的操作
	init_cmd_buffers();				//初始化命令存储缓冲区
//	htim3.Init.Prescaler = HAL_RCC_GetHCLKFreq() / 2000000;
//	;
//	htim3.Init.Period = 0xffff;
//	HAL_TIM_Base_Init(&htim3);
	init_endstop();					//Encoder_A_Pin  Encoder_B_Pin的输入，输出初始化
//	initla_encoder();
	setupPins();					//DAC数字到模拟信号初始化，及电机管脚初始化
	setupTCInterrupts();			//再次初始化定时器1
//	HAL_Delay(2000);
//	serialMenu();
	SerialUSB.printf("Ananans System Up!\n");
	SerialUSB.printf("Version %s Complie Data:%s Time:%s\n",ANANAS_VERSION, __DATE__, __TIME__);

	reset_current_data();			//iMMax  uMAX两个变量的初始化
	init_controller();				//电机管脚，从编码器读取数据更新，模式的初始化，使能定时器1的CC1输入捕获

	
	
	dirInterrupt();						
	enableInterrupt();
//	CAN_Config(&hcan);
	CAN_Configuration(canBaudRate);

	dir_485.reset();

	r = yw = 0;

	myAnanasStete.care_stop =0;//test for stop mode, be set 1 be software
}

uint8_t serialbuf[128];
uint32_t can_error_time = 0;
uint32_t can_package_get = 0;
uint8_t ErrorCode = 0;
uint32_t PID_speed;
void Ananas_Main(void) {
	if (HAL_GetTick() - LEDdelayT > LEDblinkTime) {			//1s
		PID_speed = PID_time_per_second;
		PID_time_per_second = 0;
		state_led.toggle();
//		error_led.toggle();
		LEDdelayT = HAL_GetTick();
//		SerialUSB.printf("length %d\n",length);
//		add_mode_change_time();

//		process_Step();
	}

	if (HAL_GetTick() - reportTime > stateReportTime) {		//1s
		if (is_reach_time == false) {
			SerialUSB.printf("Running Time Not Reach\n");
		}
		if (is_reach_target == false) {
			SerialUSB.printf("Running Target Nor Reach\n");
		}
		reportTime = HAL_GetTick();

//		if ((myAnanasStete.downStopState || myAnanasStete.upStopState)) {
//		if (myAnanasStete.care_stop) {
//			SerialUSB.printf("Stop Key Trigger up %d down %d p %d\n",
//					myAnanasStete.upStopState, myAnanasStete.downStopState, yw);
//		}
//		}

	}

	
	
	//USB模拟串口数据扫描
	if (need_update) {					//等于0是有接收到USB模拟串口数据，默认是1
		need_update = 0;
		if (USBD_CDC_ReceivePacket(&hUsbDeviceFS) != USBD_OK)
			need_update = 1;
	}

	//342659HZ
//	serialCheck(); //148066HZ//88376HZ
//	oneStep(); //7473HZ
//	read_QEI_encoder();
//	read_Encoder();//16520HZ
//	SerialUSB.printf("Run!!!%ld\n",length);
	
	
	//数据命令处理
	process_command();
//	SerialUSB.update();
//    move_back(10000,1000);
//    move_back(-10000,1000);

	
		
	//485数据扫描
	uint8_t len = Serial485.available();			//485接收显示
	if (len > 0) {
		if (len > 128) {
			len = 127;
		}
		num_485_rx += len;				//记录rs485总共接收到的数据条数
		Serial485.read(serialbuf, len);

		SerialUSB.printf("485 get %d %s\n", len, (char*) serialbuf);
		memset(serialbuf, 0, sizeof(serialbuf));
	}

	
	//can总线数据扫描
	if (can_rearm_rx == 1) {					//等于1没有接收到数据
		if (HAL_CAN_Receive_IT(&hcan, CAN_FIFO0) == HAL_OK) {
			/* Reception Error */
			can_rearm_rx = 0;
			num_can_re_receive++;		//记录can总线总共接收到的数据条数
		}
	}

	if (hcan.ErrorCode != HAL_CAN_ERROR_NONE) {
		ErrorCode = hcan.ErrorCode;
		CAN_Configuration(canBaudRate);
		can_error_time++;			//记录can总线错误次数
	}
}

void Ananas_Error(void) {
//	for (int i = 0; i < 3; i++) {
//		state_led.toggle();
//		HAL_Delay(200);
//	}
	LEDblinkTime = 200;
}

void HAL_TIM_OC_DelayElapsedCallback(TIM_HandleTypeDef *htim) {
	if (htim->Instance == TIM1) {
		TC5_Handler(htim);
//		length++;
	}
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *husart) {
//	if (husart == &huart1) {
//		SerialUSB.writeCallBack();
	Serial485.writeCallBack();
//	}
}
void HAL_UART_IDLE_Callback(UART_HandleTypeDef *huart) {
	if (huart == &huart1) {
//		SerialUSB.rxIdleBack();
		Serial485.rxIdleBack();
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
//	if(is_change_mode_allow() == false){
//		return;
//	}
//	__disable_irq();
	if (myAnanasStete.care_stop) {
//		if (GPIO_Pin == Encoder_A_Pin) {
//			myAnanasStete.upStopState = HAL_GPIO_ReadPin(Encoder_A_GPIO_Port,
//			Encoder_A_Pin);
//		} else if (GPIO_Pin == Encoder_B_Pin) {
//			myAnanasStete.downStopState = HAL_GPIO_ReadPin(Encoder_B_GPIO_Port,
//			Encoder_B_Pin);
//		}
	} else {
		if (GPIO_Pin == Enable_IN_Pin) {
			trigger_time[0]++;
			enableInterrupt();
		} else if (GPIO_Pin == Dir_IN_Pin) {
			trigger_time[1]++;
			dirInterrupt();
			set_input_mode('P');
		} else if (GPIO_Pin == Step_IN_Pin) {
			trigger_time[2]++;
			stepInterrupt();
			set_input_mode('P');
		}
	}
//	__enable_irq();
}
void cdc_ReceiveIsr(uint8_t *buf, uint32_t *len) {
	SerialUSB.rxCallback(buf, len);
}

void HAL_CAN_RxCpltCallback(CAN_HandleTypeDef* hcan) {
	num_can_rx++;
	if (hcan->pRxMsg->IDE == CAN_ID_EXT) {
		memcpy(&myRxMessage, hcan->pRxMsg, sizeof(CanRxMsgTypeDef));
		excuteConfiguration(&myRxMessage);
		commandCanRxMsgFlag = 1;
	} else if (hcan->pRxMsg->IDE == CAN_ID_STD) {
		process_motion(hcan);
	}
	can_package_get++;
	/* Receive */
	if (HAL_CAN_Receive_IT(hcan, CAN_FIFO0) != HAL_OK) {
		/* Reception Error */
		can_rearm_rx = 1;
	} else {
		can_rearm_rx = 0;
	}
}
