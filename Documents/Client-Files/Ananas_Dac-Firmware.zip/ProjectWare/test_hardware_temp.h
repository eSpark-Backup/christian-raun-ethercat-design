/*
 * test_hardware_temp.h
 *
 *  Created on: 2018��4��24��
 *      Author: Dark
 */

#ifndef ANANAS_DAC_PROJECTWARE_TEST_HARDWARE_TEMP_H_
#define ANANAS_DAC_PROJECTWARE_TEST_HARDWARE_TEMP_H_

#include "main.h"
#include "stm32f0xx_hal.h"



extern  CanTxMsgTypeDef TxMessage;
extern  CanRxMsgTypeDef can_rx_msg;
extern  CanRxMsgTypeDef can_rx_msg1;


void test_CAN_send(CAN_HandleTypeDef *hcan);
void CAN_Config(CAN_HandleTypeDef *CanHandle);

#endif /* ANANAS_DAC_PROJECTWARE_TEST_HARDWARE_TEMP_H_ */
