/*
 * encoder.cpp
 *
 *  Created on: 2018年8月8日
 *      Author: Dark
 */
#include "encoder.h"
#include "Parameters.h"
/* Encoder A*/
uint8_t sData[2] = { 0, 0 };
uint8_t rData[5] = { 0, 0, 0, 0, 0 };
long res = 0, res1 = 0, res2 = 0, res3 = 0;
uint8_t encoder_error = 0;
long QEI_encoderValue = 0;
volatile uint8_t QEI_encoderDir = 0;
volatile long QEI_encoderCycle = 0;

void initla_encoder() {

//	HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_2);
//	__HAL_TIM_ENABLE_IT(&htim3, TIM_IT_UPDATE);
	QEI_encoderCycle = 0;
//	htim3.Instance->CNT = 0;
	QEI_encoderCycle = 0;
}

long read_QEI_encoder() {
//	QEI_encoderValue = ENCODER_ONE_CYCLE * QEI_encoderCycle
//			+ htim3.Instance->CNT;
	return QEI_encoderValue;
}

long read_Encoder() {
	CHIPSELECT_LOW();
//	HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_RESET);
	; //CS A LOW

	//	  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
	//  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
	//  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;

	sData[0] = 0x80; //SSC Command to read the angle value
	sData[1] = 0x21;
	//HAL_SPI_TransmitReceive(&hspi1,sData,rData,2,100);

	// sData[0]=0x00;//Empty Data
	// sData[1]=0x00;
	//HAL_SPI_TransmitReceive(&hspi1,sData,rData,3,100);

	HAL_SPI_TransmitReceive(&hspi2, sData, rData, 5, 100);
//	res = (rData[0] << 8 | rData[1]) & 0x7FFF;			//15bit
//	res1 = (rData[0] << 8 | rData[1]) & 0x3FFF;			//14bit
//	res2 = (rData[0] << 9 | rData[1] << 1 | rData[2] >> 7) & 0x7FFF;
	res3 = (rData[2] << 9 | rData[3] << 1 | rData[4] >> 7) & 0x7FFF;//15bit 32768
//	res3 = (rData[2] << 8 | rData[3]) & 0x3FFF;	//14bit 16384
	CHIPSELECT_HIGH();
//	HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_SET);
	;			//CS A HIGH
	return res3;
}
