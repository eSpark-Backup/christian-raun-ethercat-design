/*
 * Ananas_Dac.h
 *
 *  Created on: 2018��8��4��
 *      Author: Dark
 */

#ifndef ANANAS_DAC_PROJECTWARE_ANANAS_DAC_H_
#define ANANAS_DAC_PROJECTWARE_ANANAS_DAC_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "stm32f0xx_hal.h"
#include "main.h"
#include "usbd_cdc_if.h"

extern ADC_HandleTypeDef hadc;
extern CAN_HandleTypeDef hcan;
//extern COMP_HandleTypeDef hcomp1;
//extern COMP_HandleTypeDef hcomp2;
extern DAC_HandleTypeDef hdac;
//extern SPI_HandleTypeDef hspi2;
//extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim1;
extern UART_HandleTypeDef huart1;
extern USBD_HandleTypeDef hUsbDeviceFS;

extern RTC_HandleTypeDef RtcHandle;

extern uint32_t LEDblinkTime;
extern volatile uint8_t need_update;

extern long trigger_time[3];

extern long num_485_rx;
extern long num_485_error;

extern long num_can_rx;
extern long num_can_re_receive;
extern uint32_t can_error_time;

extern volatile uint32_t PID_time_per_second;
void Ananas_Init(void);
void Ananas_Main(void);
void Ananas_Error(void);

void HAL_UART_IDLE_Callback(UART_HandleTypeDef *huart);
void cdc_ReceiveIsr(uint8_t *buf, uint32_t *len);

void boot_to_def(void);

#ifdef __cplusplus
}
#endif


#endif /* ANANAS_DAC_PROJECTWARE_ANANAS_DAC_H_ */
