/*
 * Ananas_Motion.h
 *
 *  Created on: 2018��10��30��
 *      Author: Dark
 */

#ifndef ANANAS_DAC_PROJECTWARE_ANANAS_MOTION_H_
#define ANANAS_DAC_PROJECTWARE_ANANAS_MOTION_H_

#include "stdint.h"
#include "string.h"
#include "Parameters.h"
#include "State.h"

enum {
	SUBDEVIDE_128 = 0, SUBDEVIDE_64, SUBDEVIDE_32, SUBDEVIDE_16, SUBDEVIDE_8
};

#define MAX_MAX_CURRENT 3 //A
#define CURRENT_DEGREE 10
#define MAX_ERROR_FOR_PULSE 50
#define EACH_ERROR_FOR_PULSE 5
#define MAX_ERROR_FOR_CAN 50
#define EACH_ERROR_FOR_CAN 10

#define HALF_CURRENT_LOW_ERROR_TIME 24000 //6s

#define MAX_UINT16_T 65536

#define CAN_RESENT_TIME  3

extern uint16_t device_id;
extern uint8_t device_id_relatic;
extern uint8_t device_id_relatic_left;
extern uint32_t canBaudRate;

extern uint16_t subdevide_choice;
extern uint16_t subdevide;
void set_devide(uint8_t chooce_devide);
void motion_parameter_reset();

extern volatile int uMAX_control;
extern float iMMMax;

extern void reset_current_data();
void current_control_For_Pulse(uint32_t error, uint32_t low_error_count);
void current_control_For_CAN(uint32_t error, uint32_t low_error_count);

void process_motion(CAN_HandleTypeDef* hcan);

void process_Step();

void send_positon_through_can(CAN_HandleTypeDef* hcan, uint8_t ID, long value,
		uint8_t care_target);
void send_velocity_through_can(CAN_HandleTypeDef* hcan, uint8_t ID, long value);
void reset_position_and_velocity(CAN_HandleTypeDef* hcan, uint8_t ID);
void emergency_stop(CAN_HandleTypeDef* hcan, uint8_t ID,uint8_t enable);
void send_go_home_can(CAN_HandleTypeDef* hcan, uint8_t ID, uint8_t dir,
		uint8_t isSoftEndStop, long feedrate, long timeout);
int travel_to_end(uint8_t dir, uint8_t isSoftEndStop, float feedrate,
		int timeout);
void move_back(float feedrate, int timeout);

#endif /* ANANAS_DAC_PROJECTWARE_ANANAS_MOTION_H_ */
